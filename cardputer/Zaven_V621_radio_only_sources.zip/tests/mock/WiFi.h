#pragma once
#include "Arduino.h"
#define WL_CONNECTED 3
typedef int wl_status_t;
struct IPAddress{int a[4]={4,3,2,1};int operator[](int i)const{return a[i];}String toString()const{return "4.3.2.1";}};
struct WiFiType{void mode(int){}void setSleep(bool){}void setAutoReconnect(bool){}void begin(const char*,const char*){}void disconnect(bool,bool){}int status(){return 0;}int channel(){return 1;}
 int RSSI(){return -44;}IPAddress gatewayIP(){return {};}IPAddress localIP(){return {};}};inline WiFiType WiFi;
