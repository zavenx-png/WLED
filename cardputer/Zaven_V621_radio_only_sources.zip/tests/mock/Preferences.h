#pragma once
#include "Arduino.h"
struct Preferences{bool begin(const char*,bool){return true;}
 uint8_t getUChar(const char*,uint8_t v){return v;}bool getBool(const char*,bool v){return v;}
 String getString(const char*,const char* v){return v;}String getString(const char*,const String& v){return v;}
 size_t getBytesLength(const char*){return 0;}size_t getBytes(const char*,void*,size_t){return 0;}
 size_t putBytes(const char*,const void*,size_t n){return n;}size_t putString(const char*,const String&){return 0;}
 size_t putUChar(const char*,uint8_t){return 0;}bool putBool(const char*,bool){return true;}void end(){}
};
