#pragma once
#include "Arduino.h"
#include "SPI.h"
#define FILE_WRITE 1
#define FILE_READ 0
struct File{String readStringUntil(char){return "";}bool available(){return false;}explicit operator bool(){return true;}void println(const char* =""){};void print(const char*){};template<typename...A>void printf(const char*,A...){ }
 size_t write(const uint8_t*,size_t n){return n;}size_t read(uint8_t*,size_t n){return n;}
 size_t size(){return 0;}void close(){};};
struct SDType{bool begin(int,SPIClass&,int){return false;}bool exists(const char*){return false;}
 bool mkdir(const char*){return true;}bool remove(const char*){return true;}File open(const char*,int){return {};}};inline SDType SD;
