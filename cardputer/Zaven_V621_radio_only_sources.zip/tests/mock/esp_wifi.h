#pragma once
#include "Arduino.h"
#define WIFI_SECOND_CHAN_NONE 0
inline int esp_wifi_set_promiscuous(bool){return 0;}
typedef int wifi_second_chan_t;
inline int esp_wifi_get_channel(uint8_t* primary,wifi_second_chan_t* secondary);
inline int esp_wifi_get_mac(int,uint8_t* mac){const uint8_t a[6]={0x24,0x58,0x44,0x12,0x34,0x56};memcpy(mac,a,6);return 0;}
inline int mockChannel=1; inline int esp_wifi_set_channel(int ch,int){mockChannel=ch;return 0;}

inline int esp_wifi_get_channel(uint8_t* primary,wifi_second_chan_t* secondary){*primary=mockChannel;*secondary=0;return 0;}
