#pragma once
#include "Arduino.h"
#include <vector>
typedef int esp_err_t;
#define ESP_OK 0
enum esp_now_send_status_t {ESP_NOW_SEND_SUCCESS=0, ESP_NOW_SEND_FAIL=1};
struct wifi_tx_info_t {};
#define WIFI_IF_STA 0
struct wifi_pkt_rx_ctrl_t{int rssi=-42;};
struct esp_now_recv_info_t{const uint8_t* src_addr=nullptr;const uint8_t* des_addr=nullptr;wifi_pkt_rx_ctrl_t* rx_ctrl=nullptr;};
struct esp_now_peer_info_t{uint8_t peer_addr[6]={};uint8_t channel=0;int ifidx=0;bool encrypt=false;};
inline std::vector<uint8_t> lastEspPacket;
inline unsigned espPacketCount=0;
inline esp_err_t esp_now_init(){return 0;}
inline esp_err_t esp_now_deinit(){return 0;}
inline esp_err_t esp_now_register_recv_cb(void (*)(const esp_now_recv_info_t*,const uint8_t*,int)){return 0;}
inline esp_err_t esp_now_register_send_cb(void (*)(const wifi_tx_info_t*,esp_now_send_status_t)){return 0;}
inline esp_err_t esp_now_add_peer(const esp_now_peer_info_t*){return 0;}
inline void (*sendHook)(const uint8_t*,size_t)=nullptr;
inline esp_err_t esp_now_send(const uint8_t*,const uint8_t* bytes,size_t size){
 lastEspPacket.assign(bytes,bytes+size);++espPacketCount;if(sendHook)sendHook(bytes,size);return 0;
}
