#pragma once
#include "Arduino.h"
struct HTTPClient{void setTimeout(int){}void setConnectTimeout(int){}bool begin(const String&){return true;}
 int GET(){return 200;}String getString(){return "{}";}void end(){}void addHeader(const char*,const char*){}int POST(const String&){return 200;}};
