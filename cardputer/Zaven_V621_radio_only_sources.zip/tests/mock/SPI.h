#pragma once
#include "Arduino.h"
#define HSPI 1
struct SPIClass{explicit SPIClass(int){}void begin(int,int,int,int){}};
inline SPIClass SPI(1);
