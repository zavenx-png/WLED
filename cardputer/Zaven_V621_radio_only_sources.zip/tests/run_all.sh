#!/bin/sh
set -eu
cd "$(dirname "$0")"
sh ./run_native_tests.sh
c++ -std=gnu++17 -I./mock discovery_tests.cpp -o /tmp/zaven_discovery_test
for ch in 1 2 3 4 5 6 7 8 9 10 11; do
 /tmp/zaven_discovery_test "$ch"
 /tmp/zaven_discovery_test "$ch" 1
done
