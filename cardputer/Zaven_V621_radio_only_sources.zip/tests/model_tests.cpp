#include "../Zaven_Festival_Kit_V6/Zaven_Festival_Kit_V6.ino"
#include <cassert>
#include <iostream>
int main(){
 using namespace FK6;
 String fx="[\"Solid\",\"RSVD\",\"Z - Meteor Circuit\",\"Z - Infinite Corridor\",\"Rainbow\"]";
 Catalog c={};int n=0;parseNames(fx,&c.fx[0][0],sizeof(c.fx[0]),MAX_FX,n);c.fxCount=n;
 assert(n==5);assert(!validFx(c.fx[1]));assert(isZ(c.fx[2]));
 parsePalNames("[\"Default\",\"Random\",\"Sunset\"]",c);
 parsePresets("{\"1\":{\"n\":\"Z - Storm\",\"seg\":[{\"fx\":2}]},\"5\":{\"n\":\"Night\"},\"25\":{\"n\":\"Playlist\",\"playlist\":{\"ps\":[1,5]}}}",c);
 finishCatalog(c);
 assert(c.zCount==2);assert(c.presetCount==3);assert(c.quickSlots[0]==1&&c.quickSlots[1]==5&&c.quickSlots[2]==25);
 assert(c.preset[25].playlist);
 Catalog highIDs;parsePresets("{\"200\":{\"n\":\"High preset\"},\"250\":{\"n\":\"Final preset\"}}",highIDs);
 assert(highIDs.quickSlots[0]==200&&highIDs.quickSlots[1]==250);
 String s="{\"on\":true,\"bri\":123,\"ps\":5,\"mainseg\":1,\"seg\":[{\"id\":0,\"fx\":7},{\"id\":1,\"fx\":2,\"sx\":44,\"ix\":70,\"pal\":3,\"o1\":true}]}";
 DeviceState st;assert(parseState(s,st));assert(st.on&&st.bri==123&&st.ps==5&&st.mainseg==1&&st.fx==2&&st.sx==44&&st.options[0]);
 String previews="{\"m\":15,\"p\":{\"2\":[[0,255,0,0],[255,0,0,255]],\"1\":[\"r\",\"r\"]}}";
 parsePalPreview(previews,c);
 assert(c.pal[2].preview && c.pal[2].dot[0]!=c.pal[2].dot[4]);
 assert(c.pal[1].dynamic && !c.pal[1].preview);
 assert(J::stringMember("{\"foo\":{\"bar\":\"x\\\"y\"},\"name\":\"Hi\"}",J::root("{\"foo\":{\"bar\":\"x\\\"y\"},\"name\":\"Hi\"}"),"name")=="Hi");
 std::cout << "V6 model/parser tests passed\n";
}
