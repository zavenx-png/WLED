#include "../Zaven_Festival_Kit_V6/Zaven_Festival_Kit_V6.ino"
#include <cassert>
#include <iostream>
int main(){
 using namespace FK6;
 Catalog& c=catalogA;c.fxCount=5;
 cpy(c.fx[0],sizeof(c.fx[0]),"Solid");cpy(c.fx[1],sizeof(c.fx[1]),"RSVD");
 cpy(c.fx[2],sizeof(c.fx[2]),"Z - Comet Storm");
 cpy(c.fx[3],sizeof(c.fx[3]),"Z - Infinite Corridor");
 cpy(c.fx[4],sizeof(c.fx[4]),"Rainbow");
 c.palCount=2;c.palOrder[0]=4;c.palOrder[1]=20;
 cpy(c.pal[4].name,sizeof(c.pal[4].name),"Ocean");
 cpy(c.pal[20].name,sizeof(c.pal[20].name),"Sunset");
 c.presetCount=2;c.presetOrder[0]=7;c.presetOrder[1]=201;
 c.quickSlots[0]=7;c.quickSlots[1]=201;
 c.preset[7].exists=true;cpy(c.preset[7].name,sizeof(c.preset[7].name),"Z - Storm");
 activeCatalog.store(&c);catReady.store(true);wifiOnline.store(false);
 espReady.store(true);v2Capable.store(true);
 app.page=HOME;app.selectedFx=2;
 pressNavigation('.');assert(app.selectedFx==3);
 assert(lastEspPacket.size()==16 && lastEspPacket[5]==6 && lastEspPacket[6]==3);
 pressNavigation(',');assert(app.selectedFx==2);
 assert(lastEspPacket[5]==6 && lastEspPacket[6]==2);
 stepFx(-1,true);assert(app.selectedFx==3 && lastEspPacket[5]==6);
 app.page=PALETTE_PAGE;app.paletteRow=0;pressNavigation('.');assert(app.paletteRow==1);
 doEnter();assert(lastEspPacket[5]==7&&lastEspPacket[6]==20&&app.page==HOME);
 menuKey('2');assert(lastEspPacket[5]==1&&lastEspPacket[6]==201);
 deviceState.bri=100;app.page=HOME;setBrightnessStep(1);
 assert(app.brightness==106&&app.page==BRIGHT_PAGE);
 assert(lastEspPacket[5]==2&&lastEspPacket[6]==106);
 app.page=HOME;menuKey('p');assert(lastEspPacket[5]==3);
 app.page=HOME;menuKey('x');assert(lastEspPacket[5]==5);
 app.page=PALETTE_PAGE;app.paletteRow=1;togglePaletteFavorite(20);assert(isFavoritePalette(20));
 app.onlyFavPalettes=true;assert(visiblePaletteCount()==1);
 selectPalette(0);assert(app.selectedPal==20);
 assert(paletteAtRow(0)==20&&paletteAtRow(1)==-1);
 app.onlyFavPalettes=false;assert(visiblePaletteCount()==2);
 String labels[8];bool enabled[8];
 cpy(c.metadata[3],sizeof(c.metadata[3]),"Z - Infinite Corridor@Speed,Intensity,Depth,,,!;Color;;");
 assert(settingLabels(3,labels,enabled)==3);
 assert(labels[0]=="Speed"&&labels[1]=="Intensity"&&labels[2]=="Depth");
 // ACK v2 round-trip: current WLED state is reflected without Wi-Fi.
 uint32_t seq=txSequence.load();
 uint8_t ack[24]={'Z','H','A','2',2,8,0,1,177,201,3,0,20,111,222,2,
   uint8_t(seq),uint8_t(seq>>8),uint8_t(seq>>16),uint8_t(seq>>24),2,5,7,5};
 esp_now_recv_info_t info;wifi_pkt_rx_ctrl_t ctrl;info.rx_ctrl=&ctrl;
 radioReceive(&info,ack,24);
 DeviceState d=getDevice();
 assert(v2Capable.load()&&d.bri==177&&d.ps==201&&d.fx==3);
 assert(d.pal==20&&d.sx==111&&d.ix==222&&d.mainseg==2);
 assert(d.c1==2&&d.c2==5&&d.c3==7);
 assert(d.options[0]&&d.options[2]&&!d.options[1]);
 // V1 response still works for fallback commands.
 uint8_t a1[13]={'Z','H','A','1',1,8,0,150,7,
   uint8_t(seq),uint8_t(seq>>8),uint8_t(seq>>16),uint8_t(seq>>24)};
 radioReceive(&info,a1,13);assert(legacyCapable.load());
 std::cout<<"V6 ESP-NOW-first tests passed: "<<sizeof(Catalog)<<" bytes catalog\n";
}
