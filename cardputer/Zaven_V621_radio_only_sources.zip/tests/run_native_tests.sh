#!/bin/sh
set -eu
cd "$(dirname "$0")"
CXX="${CXX:-c++}"
"$CXX" -std=gnu++17 -Wall -Wextra -Wno-unused-function -I./mock -fsyntax-only native_syntax.cpp
"$CXX" -std=gnu++17 -I./mock model_tests.cpp -o /tmp/festival_v6_model_test
/tmp/festival_v6_model_test
"$CXX" -std=gnu++17 -I./mock control_tests.cpp -o /tmp/festival_v6_control_test
/tmp/festival_v6_control_test
printf '\nNative test suite passed. Note: not an Arduino hardware compile.\n'
