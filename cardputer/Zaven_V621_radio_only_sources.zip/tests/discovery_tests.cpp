#include "../Zaven_Festival_Kit_V6/Zaven_Festival_Kit_V6.ino"
#include <cassert>
#include <iostream>
struct Stop {};
static uint32_t start=0, acquired=0;
static void reply(const uint8_t* packet, size_t size){
  // Simulate the harness operating on channel 1. A reply is possible ONLY on CH1.
  assert(mockChannel==1);
  if(size!=16)return;
  uint8_t ack[24]={'Z','H','A','2',2,8};
  memcpy(ack+16,packet+12,4);
  esp_now_recv_info_t info{};
  FK6::radioReceive(&info,ack,24);
  if(!acquired)acquired=millis();
}
static void advance(int){if(millis()-start>=2200)throw Stop{};}
int main(){
  using namespace FK6;
  start=millis();sendHook=reply;delayHook=advance;txSequence=100;
  // Old prefs can contain any channel; network worker must remain fixed on CH1.
  savedRadioChannel.store(11);
  try{networkTask(nullptr);}catch(Stop&){}
  assert(acquired);
  assert(mockChannel==1);
  assert(radioChannel.load()==1);
  assert(ackPackets.load()>0);
  assert(txQueued.load()>0 && txQueueErrors.load()==0);
  assert(observedPrimary.load()==1);
  std::cout<<"CH1 locked, actual channel readback, queued TX and ACK diagnostics OK\n";
}
