# ZAVEN V6.2.1 — ESP-NOW RADIO-ONLY DIAGNOSTIC FIX

Based exclusively on the user-supplied Zaven_V6_2.zip.

## Only modified firmware file
- Zaven_Festival_Kit_V6/V6_Network.h

The UI, screen initialization, rotation and all other firmware headers are byte-for-byte unchanged from V6.2.

## Changes
- Fixed ESP-NOW to channel 1 (Harness-AP Always, channel 1); no 120-ms 11-channel scanning.
- No automatic WLED Wi-Fi connection; K remains manual catalog sync.
- ESP-NOW send completion callback and enqueue error counters.
- Actual channel readback with esp_wifi_get_channel() instead of assuming set succeeded.
- Display actual Cardputer STA MAC in USB serial diagnostics every 3.5 seconds at 115200 baud.
- Raw incoming ESP-NOW packet count and invalid ACK counts.
- Delayed ACK tolerance increased to 64 recent command sequence numbers.
- V1 fallback ping approximately every fourth offline ping; V2 is preferred.
- Background radio ping interval 800ms while offline, 1500ms when linked.
- Print ESP-NOW init, peer setup, channel-setting and send-error status codes.

## Verify the radio
1. Keep your WLED Harness V5.3 + ESP-NOW V2 installed; don't reflash WLED.
2. WLED Config -> WiFi Setup: AP Opens=Always, channel=1, Enable ESP-NOW checked. Verify WLED Remote List matches the serial STA MAC.
3. Flash ONLY the app .bin built from this source via M5Launcher.
4. Open a USB Serial Monitor at 115200 and press T repeatedly. Copy the lines prefixed 'V6 RADIO'.
5. An accepted TX queue or even successful broadcast send callback does not establish that WLED received it. Only an ACK establishes application response.
6. Once working, press K for optional Wi-Fi catalog sync.

## Interpretation
- `ESP-NOW=0` or nonzero `init-rc`: local radio failed to initialize.
- Nonzero `channel-rc` or `actual!=1`: radio not on intended channel.
- Nonzero `send-rc` or increasing `enqueue-error`: local send queue failure.
- Increasing `callback-ok` but no `ACK`: broadcast queued for radio; destination reception not established.
- `RX-raw` increasing without `ACK`: device hears ESP-NOW traffic but not valid matching protocol replies.
- WLED `Last device seen=None` means WLED has not recorded a sender in its receiver; verify STA MAC, WLED AP/STA interface and channel.

## Build
Arduino CLI: install M5Stack ESP32 core 3.3.10 and M5Cardputer library. Board M5Cardputer, Huge APP (3MB No OTA), export application .bin. Toolchain confirmation from Github Actions is included only when actually obtained.
