#pragma once
/*
 * Zero-dependency JSON span scanner for bounded WLED payloads.
 * Does not allocate token trees or depend on ArduinoJson versions.
 * Objects/arrays never copied unless explicitly requested.
 */
namespace FK6 {
namespace J {
struct Span { int a=-1, b=-1; bool ok() const { return a>=0 && b>=a; } };
static inline bool ws(char c) { return c==' '||c=='\n'||c=='\t'||c=='\r'; }
static void skip(const String& s,int& p) { while(p<(int)s.length()&&ws(s[p]))++p; }
static Span value(const String& s,int& p) {
  skip(s,p); int a=p; if(p>=(int)s.length()) return {};
  char lead=s[p++];
  if(lead=='"') {
    bool esc=false;
    while(p<(int)s.length()) { char c=s[p++]; if(esc) esc=false; else if(c=='\\')esc=true; else if(c=='"')break; }
    return {a,p};
  }
  if(lead=='{'||lead=='[') {
    int depth=1; bool quoted=false,esc=false;
    while(p<(int)s.length()&&depth>0) {
      char c=s[p++]; if(quoted) {if(esc)esc=false;else if(c=='\\')esc=true;else if(c=='"')quoted=false;}
      else {if(c=='"')quoted=true;else if(c=='{'||c=='[')++depth;else if(c=='}'||c==']')--depth;}
    }
    return depth==0?Span{a,p}:Span{};
  }
  while(p<(int)s.length()&&s[p]!=','&&s[p]!=']'&&s[p]!='}'&&!ws(s[p]))++p;
  return {a,p};
}
static String decoded(const String& s, Span v) {
  String out; if(!v.ok())return out;
  if(s[v.a]!='"')return s.substring(v.a,v.b);
  for(int p=v.a+1;p<v.b-1;++p) {
    char c=s[p]; if(c=='\\'&&p+1<v.b-1){c=s[++p];if(c=='n'||c=='r'||c=='t')c=' ';
      else if(c=='u'){p+=4;c='?';}}
    if((unsigned char)c>=32&&((unsigned char)c<127))out+=c;
  }return out;
}
static int integer(const String& s, Span v,int def=0) {
  if(!v.ok())return def;
  int a=v.a;while(a<v.b&&ws(s[a]))++a;
  if(a>=v.b)return def;
  if((s[a]<'0'||s[a]>'9')&&s[a]!='-')return def;
  return s.substring(a,v.b).toInt();
}
static bool boolean(const String& s,Span v,bool def=false){if(!v.ok())return def;return s[v.a]=='t'?true:(s[v.a]=='f'?false:def);}
struct ObjectIterator {
  const String& s; int p,end; String key; Span v;
  explicit ObjectIterator(const String& json,Span o):s(json),p(o.a+1),end(o.b-1) {}
  bool next() {
    while(p<end) { skip(s,p);if(p>=end||s[p]=='}')return false;
      if(s[p]==','){p++;continue;}if(s[p]!='"')return false;
      Span k=value(s,p);key=decoded(s,k);skip(s,p);if(p>=end||s[p++]!=':')return false;
      v=value(s,p);return v.ok();
    }return false;
  }
};
struct ArrayIterator {
  const String& s;int p,end;Span v;int index=-1;
  explicit ArrayIterator(const String& json,Span a):s(json),p(a.a+1),end(a.b-1){}
  bool next(){while(p<end){skip(s,p);if(p>=end||s[p]==']')return false;
    if(s[p]==','){p++;continue;}v=value(s,p);++index;return v.ok();}return false;}
};
static Span root(const String& s){int p=0;return value(s,p);}
static Span member(const String& s,Span object,const char* key) {
  if(!object.ok()||s[object.a]!='{')return {};
  ObjectIterator it(s,object);while(it.next())if(it.key==key)return it.v;return {};
}
static Span item(const String& s,Span array,int index) {
  if(!array.ok()||s[array.a]!='[')return {};
  ArrayIterator it(s,array);while(it.next())if(it.index==index)return it.v;return {};
}
static String stringMember(const String& s,Span obj,const char* name,const String& def=""){
  Span x=member(s,obj,name);return x.ok()?decoded(s,x):def;
}
static int intMember(const String& s,Span obj,const char* name,int def=0){return integer(s,member(s,obj,name),def);}
static bool boolMember(const String& s,Span obj,const char* name,bool def=false){return boolean(s,member(s,obj,name),def);}
static String escape(const String& input){String out;out.reserve(input.length()+8);for(size_t i=0;i<input.length();i++){
  char c=input[i];if(c=='\\'||c=='"'){out+='\\';out+=c;}
  else if(c=='\n'||c=='\r'){out+=' ';}
  else if((unsigned char)c>=32)out+=c;
 }return out;
}
}
}
