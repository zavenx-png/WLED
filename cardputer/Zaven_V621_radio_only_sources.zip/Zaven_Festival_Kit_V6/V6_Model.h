#pragma once
#include <M5Cardputer.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <Preferences.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <SPI.h>
#include <SD.h>
#include <atomic>
#include <new>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "V6_Json.h"

namespace FK6 {
constexpr int MAX_FX=256,MAX_PALETTES=256,MAX_PRESETS=250;
constexpr uint32_t LINK_TIMEOUT=2400;
constexpr uint16_t BG=0x0862,PANEL=0x10C4,PANEL2=0x2165;
constexpr uint16_t TEXT=0xFFFF,FAINT=0x9CB3,SUBTLE=0x6B4D;
constexpr uint16_t ACCENT=0x0E9F,PINK=0xF2FF,GREEN=0x57EB,AMBER=0xFDC0,ALERT=0xF986;

static void cpy(char* dest,size_t cap,const String& s){if(!cap)return;size_t n=s.length();if(n>=cap)n=cap-1;memcpy(dest,s.c_str(),n);dest[n]=0;}
static bool containsCI(const char* hay,const String& needle){if(!needle.length())return true;String a(hay),b(needle);a.toLowerCase();b.toLowerCase();return a.indexOf(b)>=0;}
static bool isZ(const char* label){while(*label==' ')++label;return (label[0]=='Z'||label[0]=='z')&&(label[1]==' '||label[1]=='-'||label[1]=='_'||label[1]==':'||label[1]==0);}
static bool validFx(const char* label){return label[0]&&strcmp(label,"RSVD")!=0&&strcmp(label,"-")!=0&&strcmp(label,"Reserved")!=0;}

struct Preset {char name[64];bool exists;bool playlist;};
struct Palette {char name[40];uint16_t dot[5];bool preview;bool dynamic;bool exists;};
struct Catalog {
  uint16_t fxCount=0,palCount=0,presetCount=0,zCount=0;
  uint8_t mainseg=0;char device[36]="WLED HARNESS";
  char fx[MAX_FX][64]={{0}};
  char metadata[MAX_FX][110]={{0}};
  uint8_t zFx[MAX_FX]={0};
  Palette pal[MAX_PALETTES]={};
  uint8_t palOrder[MAX_PALETTES]={0};
  Preset preset[MAX_PRESETS+1]={};
  uint8_t presetOrder[MAX_PRESETS]={0};
  int16_t quickSlots[10]={-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
};

struct DeviceState {
  bool on=false;uint8_t bri=100;int16_t ps=-1,fx=0,pal=0;
  uint8_t sx=128,ix=128,c1=128,c2=128,c3=16;
  bool options[3]={false,false,false};
  uint8_t mainseg=0;int8_t wifiRSSI=0,espRSSI=0;
  uint32_t lastState=0,lastAck=0;int16_t ledCount=0;
};
struct Profile {char ssid[40]="Harness-AP";char password[65]="wled1234";char host[40]="";};
struct RadioStats {uint32_t sent=0,acked=0,failed=0,lastSeq=0;uint8_t lastCmd=0,lastStatus=0;};
struct Action {
  uint8_t type=0;int16_t a=0,b=0;char text[224]={0};
};
enum ActionType:uint8_t {ACT_FX=1,ACT_PAL,ACT_PRESET,ACT_SET,ACT_SAVE,ACT_DUP,ACT_PLAYLIST,ACT_REFRESH,ACT_STATE,ACT_RENAME,ACT_LIVE};

static Catalog catalogA,catalogB;
static std::atomic<Catalog*> activeCatalog(nullptr);
static DeviceState deviceState;
static portMUX_TYPE deviceMux=portMUX_INITIALIZER_UNLOCKED;
static portMUX_TYPE profileMux=portMUX_INITIALIZER_UNLOCKED;
static Profile profiles[3];static std::atomic<int> profileIndex(0),profileChange(0);
static std::atomic<bool> wifiOnline(false),espReady(false),catReady(false),netBusy(false);
static std::atomic<int> workerState(0),radioChannel(1),lastHttpCode(0),errorCount(0);
static std::atomic<uint32_t> ackTime(0),sentPackets(0),ackPackets(0),lastSync(0);
static std::atomic<int> espRssi(0);
static String baseUrl="http://4.3.2.1"; // only accessed in network task
static portMUX_TYPE actionMux=portMUX_INITIALIZER_UNLOCKED;
static Action queue[16];static uint8_t qHead=0,qTail=0;static std::atomic<uint16_t> droppedActions(0);
static Preferences prefs;
static uint8_t profileCurrent=0;
static bool sdReady=false;
static std::atomic<bool> radioScanning(false);
static std::atomic<int> httpBrightness(-1);
static std::atomic<bool> catalogCachePending(false);
static std::atomic<uint32_t> paletteVersion(0),liveVersion(0);
static uint16_t livePixels[24]={0};static std::atomic<bool> liveValid(false);
static bool writeCatalogCache();
static uint32_t profileHash(){
 uint32_t h=2166136261u;int p=profileIndex.load();for(const char* s=profiles[p].ssid;*s;s++){h^=(uint8_t)*s;h*=16777619u;}return h;
}
static std::atomic<uint32_t> txSequence(0);
static std::atomic<bool> syncRequested(false),syncInProgress(false),v2Capable(false),legacyCapable(false);
static std::atomic<bool> radioLinkSeen(false);
static std::atomic<bool> syncCompleted(false);
static const uint8_t BCAST[6]={255,255,255,255,255,255};

static DeviceState getDevice(){DeviceState s;portENTER_CRITICAL(&deviceMux);s=deviceState;portEXIT_CRITICAL(&deviceMux);return s;}
static void putDevice(const DeviceState& s){portENTER_CRITICAL(&deviceMux);deviceState=s;portEXIT_CRITICAL(&deviceMux);}
static bool enqueue(const Action& a){bool ok=false;portENTER_CRITICAL(&actionMux);
 uint8_t next=(qHead+1)%16;
 if(next!=qTail){queue[qHead]=a;qHead=next;ok=true;}
 portEXIT_CRITICAL(&actionMux);if(!ok)droppedActions.fetch_add(1);return ok;
}
static bool takeAction(Action& a){bool ok=false;portENTER_CRITICAL(&actionMux);
 if(qTail!=qHead){a=queue[qTail];qTail=(qTail+1)%16;ok=true;}
 portEXIT_CRITICAL(&actionMux);return ok;
}
static void clearActions(){portENTER_CRITICAL(&actionMux);qHead=qTail=0;portEXIT_CRITICAL(&actionMux);}
static bool action(uint8_t type,int a=0,int b=0,const String& text=""){
 Action cmd;cmd.type=type;cmd.a=(int16_t)a;cmd.b=(int16_t)b;cpy(cmd.text,sizeof(cmd.text),text);return enqueue(cmd);
}
static uint16_t rgb565(uint8_t r,uint8_t g,uint8_t b){return ((r&0xF8)<<8)|((g&0xFC)<<3)|(b>>3);}

// Parse one catalog endpoint into an inactive buffer. Only the network task
// modifies Catalog objects. The main thread reads the published pointer.
static void parseNames(const String& json,char* ptr,size_t stride,int limit,int& count){
 J::Span root=J::root(json);count=0;if(!root.ok()||json[root.a]!='[')return;
 J::ArrayIterator it(json,root);while(it.next()&&it.index<limit){
  String name=J::decoded(json,it.v);cpy(ptr+(size_t)it.index*stride,stride,name);count=it.index+1;
 }
}
static void parsePresets(const String& json,Catalog& cat){
 J::Span root=J::root(json);if(!root.ok()||json[root.a]!='{')return;
 J::ObjectIterator it(json,root);
 while(it.next()) {int id=it.key.toInt();if(id<1||id>250||json[it.v.a]!='{')continue;
  String name=J::stringMember(json,it.v,"n","Preset "+String(id));
  Preset& p=cat.preset[id];cpy(p.name,sizeof(p.name),name);p.exists=true;
  p.playlist=J::member(json,it.v,"playlist").ok();
 }
 cat.presetCount=0;for(int id=1;id<=MAX_PRESETS;id++)if(cat.preset[id].exists){
  cat.presetOrder[cat.presetCount++]=(uint8_t)id;
 }
 for(int i=0;i<10;i++)cat.quickSlots[i]=(i<cat.presetCount)?cat.presetOrder[i]:-1;
}
static void parsePalNames(const String& json,Catalog& cat) {
 J::Span root=J::root(json);if(!root.ok()||json[root.a]!='[')return;
 J::ArrayIterator it(json,root);
 while(it.next()&&it.index<MAX_PALETTES){
  String name=J::decoded(json,it.v);
  if(name.length()){
    Palette& p=cat.pal[it.index];cpy(p.name,sizeof(p.name),name);p.exists=true;
  }
 }
}
static void rebuildPalOrder(Catalog& cat){cat.palCount=0;
 for(int i=0;i<MAX_PALETTES;i++)if(cat.pal[i].exists)cat.palOrder[cat.palCount++]=i;
}
// Read one WLED /json/palx?page=N response. RGB stops are [index,r,g,b].
// For tokens such as "r" / "c1", no actual fixed color can be inferred.
static void parsePalPreview(const String& json,Catalog& cat){
 J::Span root=J::root(json),p=J::member(json,root,"p");if(!p.ok())return;
 J::ObjectIterator it(json,p);
 while(it.next()){
  int id=it.key.toInt();if(id<0||id>=MAX_PALETTES)continue;
  Palette& dest=cat.pal[id];dest.exists=true;
  if(!dest.name[0]){char buf[40];snprintf(buf,sizeof(buf),"Custom palette %d",id);cpy(dest.name,sizeof(dest.name),String(buf));}
  uint8_t idx[32],r[32],g[32],b[32];int count=0;bool dynamic=false;
  if(json[it.v.a]=='['){
   J::ArrayIterator pt(json,it.v);
   while(pt.next()&&count<32){
     if(json[pt.v.a]=='['){
       J::ArrayIterator col(json,pt.v);int arr[4]={0,0,0,0};int n=0;
       while(col.next()&&n<4)arr[n++]=J::integer(json,col.v);
       if(n==4){idx[count]=constrain(arr[0],0,255);r[count]=constrain(arr[1],0,255);
        g[count]=constrain(arr[2],0,255);b[count]=constrain(arr[3],0,255);count++;}
     }else if(json[pt.v.a]=='"')dynamic=true;
   }
  }
  if(count==0){dest.dynamic=true;dest.preview=false;continue;}
  for(int sample=0;sample<5;sample++){
    int x=(sample*255)/4,i=0;
    while(i+1<count&&idx[i+1]<x)i++;
    int j=min(count-1,i+1),t=(i==j||idx[j]<=idx[i])?0:(x-idx[i])*256/(idx[j]-idx[i]);
    int R=constrain((int)r[i]+((int)r[j]-(int)r[i])*t/256,0,255);
    int G=constrain((int)g[i]+((int)g[j]-(int)g[i])*t/256,0,255);
    int B=constrain((int)b[i]+((int)b[j]-(int)b[i])*t/256,0,255);
    dest.dot[sample]=rgb565(R,G,B);
  }
  dest.preview=true;dest.dynamic=dynamic;
 }
}
static void parseFxMeta(const String& json,Catalog& cat){int n=0;
 parseNames(json,&cat.metadata[0][0],sizeof(cat.metadata[0]),MAX_FX,n);
}
static void finishCatalog(Catalog& cat){cat.zCount=0;
 for(int i=0;i<cat.fxCount;i++)if(validFx(cat.fx[i])&&isZ(cat.fx[i]))cat.zFx[cat.zCount++]=i;
 rebuildPalOrder(cat);
}
static bool parseState(const String& json,DeviceState& st){
 J::Span root=J::root(json);if(!root.ok()||json[root.a]!='{')return false;
 st.on=J::boolMember(json,root,"on",st.on);st.bri=constrain(J::intMember(json,root,"bri",st.bri),0,255);
 st.ps=J::intMember(json,root,"ps",st.ps);st.mainseg=constrain(J::intMember(json,root,"mainseg",st.mainseg),0,63);
 J::Span segs=J::member(json,root,"seg");
 if(segs.ok()&&json[segs.a]=='['){J::ArrayIterator it(json,segs);J::Span chosen;
  while(it.next())if(json[it.v.a]=='{'&&J::intMember(json,it.v,"id",it.index)==st.mainseg){chosen=it.v;break;}
  if(!chosen.ok()){chosen=J::item(json,segs,0);}
  if(chosen.ok()&&json[chosen.a]=='{'){
   st.fx=J::intMember(json,chosen,"fx",st.fx);st.pal=J::intMember(json,chosen,"pal",st.pal);
   st.sx=constrain(J::intMember(json,chosen,"sx",st.sx),0,255);
   st.ix=constrain(J::intMember(json,chosen,"ix",st.ix),0,255);
   st.c1=constrain(J::intMember(json,chosen,"c1",st.c1),0,255);
   st.c2=constrain(J::intMember(json,chosen,"c2",st.c2),0,255);
   st.c3=constrain(J::intMember(json,chosen,"c3",st.c3),0,31);
   st.options[0]=J::boolMember(json,chosen,"o1",st.options[0]);
   st.options[1]=J::boolMember(json,chosen,"o2",st.options[1]);
   st.options[2]=J::boolMember(json,chosen,"o3",st.options[2]);
  }
 }
 st.lastState=millis();return true;
}
// Safe, non-destructive setters: never send segment bounds, ledmap, reverse,
// output pin layouts, or group/spacing data unless explicitly requested.
static String segmentPatch(int segment,const String& attrs){
 return String("{\"seg\":[{\"id\":")+segment+","+attrs+"}]}";
}
static String getFxLabel(const Catalog* c,int id){
 if(c&&id>=0&&id<c->fxCount&&c->fx[id][0])return String(c->fx[id]);
 return id>=0?"Effect "+String(id):"SELECT AN EFFECT";
}
static String getPresetLabel(const Catalog* c,int id){
 if(c&&id>=1&&id<=MAX_PRESETS&&c->preset[id].exists)return String(c->preset[id].name);
 return id>=1?"Preset "+String(id):"SELECT A PRESET";
}
}
