# Festival Kit V6 ESP-NOW First — key map

| Key | Function |
|---|---|
| `1–9`, `0` | First ten WLED presets in the cached preset list (actual WLED IDs) |
| `,` / `.` | Previous / next WLED effect, **without Fn/Aa** |
| `[` / `]` | Previous / next `Z -` effects |
| `;`, `,`, `.`, `/` | Physical up/left/down/right navigation positions in menus, without Fn |
| `P` | Toggle harness power (ESP-NOW) |
| `X` | Blackout (ESP-NOW) |
| `+` / `-` | Brightness ±6/255; hold for slower continuous movement. Enter or 3-second idle closes overlay |
| `C` | WLED palette browser; 5 stored preview dots per palette; Enter applies using ESP-NOW |
| `E` / `/` on home | Dynamic WLED effect settings (ESP-NOW), populated from cached metadata |
| `S` | Save a named preset (temporary Wi-Fi operation, then disconnect and refresh cache) |
| `K` | **One-time Wi-Fi catalog refresh** (then disconnect automatically) |
| `M` | Full control menu (including Wi-Fi-only administrative tools) |
| `B` | All cached saved presets |
| `G` | All effects browser |
| `V` | Favorite effects browser; on palette screen switches favorite palette filter |
| `F` | Favorite highlighted effect / palette |
| `Y` | Favorite bank 1–3 |
| `Q` | Search cached effects |
| `R` | Random cached effect |
| `Z` | Undo effect/settings using ESP-NOW V2 |
| `A` | Automatic rotation of cached effects/presets |
| `I` | Radio/channel/protocol/catalog diagnostics |
| `D` | Cardputer battery and screen settings |
| `W` | Connection profiles (SSID/password/optional host for manual sync) |
| `T` | ESP-NOW ping |
| `L` | Lock controls; hold L to unlock |
| `U` | Local BPM tap (does not transmit BPM) |
| `H` / `Tab` | Built-in help; Tab cycles help pages |
| Esc/backtick or Del | Home/effect selection screen (Backspace deletes character while editing text) |

## Palette picker

- `;`/`,` move to previous palette; `.`/`/` move to next.
- Enter selects WLED palette using ESP-NOW, even when Wi-Fi is off.
- `F` adds/removes a palette favorite; `V` filters favorites.
- Five dots are stored from WLED `/json/palx` previews. If palette is dynamic, preview is marked accordingly.

## Note about administrative actions

Saving, duplicating, renaming WLED presets and editing playlists invokes a temporary Wi-Fi JSON API session, not the V2 radio protocol. The app returns to ESP-NOW afterwards and updates the saved catalog. Those actions are slower and should not be needed during ordinary festival use.

| `O` | Rotate Cardputer screen between portrait and landscape orientations (0,1,2,3), saved across restarts |
