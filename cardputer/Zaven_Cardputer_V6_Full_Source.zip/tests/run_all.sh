#!/bin/sh
set -eu
cd "$(dirname "$0")"
sh ./run_native_tests.sh
python3 ./test_wled_protocol.py
python3 ./test_patch_integration.py
python3 -m py_compile ../WLED_HARNESS_PATCH/install_protocol_v2.py
printf '\nAll source-level tests passed; hardware compilation remains unverified.\n'
