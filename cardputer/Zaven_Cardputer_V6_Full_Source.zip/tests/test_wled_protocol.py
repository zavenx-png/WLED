#!/usr/bin/env python3
"""Compile WLED-side protocol against deterministic stand-ins, then exercise packets."""
import ast, pathlib, subprocess, tempfile, textwrap
installer=pathlib.Path(__file__).resolve().parents[1]/'WLED_HARNESS_PATCH/install_protocol_v2.py'
tree=ast.parse(installer.read_text())
replacement=None
for node in tree.body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='replacement' for t in node.targets):
  replacement=ast.literal_eval(node.value)
assert replacement and 'ZAVEN ESP-NOW V2 / ZHR2' in replacement
preamble=r'''
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <vector>
#include <array>
#include <algorithm>
#include <cassert>
using byte=uint8_t;
#define ARDUINO_ARCH_ESP32 1
#define WLED_DISABLE_ESPNOW_UNUSED 1
typedef int portMUX_TYPE;
#define portMUX_INITIALIZER_UNLOCKED 0
#define portENTER_CRITICAL(x) (void)(x)
#define portEXIT_CRITICAL(x) (void)(x)
#define CALL_MODE_BUTTON_PRESET 1
#define CALL_MODE_BUTTON 2
#define ESP_NOW_STATE_ON 1
int statusESPNow=ESP_NOW_STATE_ON;
const uint8_t ESPNOW_BROADCAST_ADDRESS[6]={255,255,255,255,255,255};
std::vector<std::array<char,13>> linked_remotes={{'a','a','b','b','c','c','d','d','e','e','f','f','\0'}};
struct Segment {
  uint8_t mode=3,palette=2,speed=100,intensity=130,custom1=12,custom2=18,custom3=3;
  bool check1=false,check2=false,check3=false;
  int modeSets=0,paletteSets=0;
  void setMode(uint8_t fx,bool){mode=fx;modeSets++;}
  void setPalette(uint8_t pal){palette=pal;paletteSets++;}
  int getLightCapabilities(){return 1;}
};
struct Strip {
 Segment main;
 Segment& getMainSegment(){return main;}
 unsigned getModeCount(){return 256;}
 uint8_t getMainSegmentId(){return 2;}
} strip;
unsigned getPaletteCount(){return 256;}
uint8_t bri=120,currentPreset=3;
int updates=0;
void stateUpdated(int){updates++;}
void applyPreset(uint8_t id,int){currentPreset=id;}
void unloadPlaylist(){}
void toggleOnOff(){bri=bri?0:120;}
int currentPlaylist=-1;
namespace wled {struct Now {
 std::vector<uint8_t> last;
 void send(const uint8_t*,const uint8_t* data,size_t n){last.assign(data,data+n);}
} espNow;}
'''
main=r'''
int main(){
 uint8_t sender[6]={0xaa,0xbb,0xcc,0xdd,0xee,0xff};
 auto queue=[&](const uint8_t* packet,uint8_t len){
   uint8_t n=zh_radio_head;
   memcpy(zh_radio_packets[n],packet,len);
   memcpy(zh_radio_senders[n],sender,6);
   zh_radio_lengths[n]=len;
   zh_radio_head=(zh_radio_head+1)%12;
 };
 uint8_t c[16]={'Z','H','R','2',2,6,51,0,255,0,0,0,1,0,0,0};
 queue(c,16);zh_radio_process();
 assert(strip.main.mode==51 && updates==1);
 assert(wled::espNow.last.size()==24);
 assert(wled::espNow.last[10]==51 && wled::espNow.last[16]==1);
 // Replayed sequence does not apply twice.
 queue(c,16);zh_radio_process();assert(strip.main.modeSets==1);
 c[5]=7;c[6]=31;c[12]=2;queue(c,16);zh_radio_process();
 assert(strip.main.palette==31 && wled::espNow.last[12]==31);
 c[5]=9;c[6]=1;c[9]=5;c[12]=3;queue(c,16);zh_radio_process();
 assert(strip.main.check1 && wled::espNow.last[23]==1);
 c[5]=2;c[6]=80;c[9]=0;c[12]=4;queue(c,16);zh_radio_process();
 assert(bri==80 && wled::espNow.last[8]==80);
 c[5]=1;c[6]=201;c[12]=5;queue(c,16);zh_radio_process();
 assert(currentPreset==201 && wled::espNow.last[9]==201);
 // Unpaired packet would be refused by callback; the execution side also rejects it.
 char oldstate=wled::espNow.last[5];
 memcpy(zh_radio_senders[zh_radio_head],"xxxxxx",6);
 memcpy(zh_radio_packets[zh_radio_head],c,16);
 zh_radio_lengths[zh_radio_head]=16;
 zh_radio_head=(zh_radio_head+1)%12;
 zh_radio_process();assert(wled::espNow.last[5]==oldstate);
 // V1 ping still generates V1 ACK for backward compatibility.
 uint8_t old[12]={'Z','H','R','1',1,8,0,0,6,0,0,0};queue(old,12);zh_radio_process();
 assert(wled::espNow.last.size()==13);
 // No original harness layout/geometry API used.
 assert(strip.getMainSegmentId()==2);
}
'''
with tempfile.TemporaryDirectory(prefix='zaven_wled_proto_') as temp:
 cpp=pathlib.Path(temp)/'test.cpp';cpp.write_text(preamble+'\n'+replacement+'\n'+main)
 cmd=['c++','-std=gnu++17','-Wall','-Wextra','-Werror','-o',str(pathlib.Path(temp)/'test'),str(cpp)]
 subprocess.run(cmd,check=True)
 subprocess.run([str(pathlib.Path(temp)/'test')],check=True)
print('WLED ZHR2/ZHA2 protocol compile + simulated packet/ACK tests passed')
