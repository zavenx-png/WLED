#pragma once
#include "Arduino.h"
#include <vector>
typedef int esp_err_t;
#define ESP_OK 0
#define WIFI_IF_STA 0
struct wifi_pkt_rx_ctrl_t{int rssi=-42;};
struct esp_now_recv_info_t{const uint8_t* src_addr=nullptr;const uint8_t* des_addr=nullptr;wifi_pkt_rx_ctrl_t* rx_ctrl=nullptr;};
struct esp_now_peer_info_t{uint8_t peer_addr[6]={};uint8_t channel=0;int ifidx=0;bool encrypt=false;};
inline std::vector<uint8_t> lastEspPacket;
inline unsigned espPacketCount=0;
inline esp_err_t esp_now_init(){return 0;}
inline esp_err_t esp_now_deinit(){return 0;}
inline esp_err_t esp_now_register_recv_cb(void (*)(const esp_now_recv_info_t*,const uint8_t*,int)){return 0;}
inline esp_err_t esp_now_add_peer(const esp_now_peer_info_t*){return 0;}
inline esp_err_t esp_now_send(const uint8_t*,const uint8_t* bytes,size_t size){
 lastEspPacket.assign(bytes,bytes+size);++espPacketCount;return 0;
}
