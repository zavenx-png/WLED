#pragma once
#include "Arduino.h"
#define WIFI_SECOND_CHAN_NONE 0
inline int esp_wifi_set_promiscuous(bool){return 0;}
inline int esp_wifi_set_channel(int,int){return 0;}
