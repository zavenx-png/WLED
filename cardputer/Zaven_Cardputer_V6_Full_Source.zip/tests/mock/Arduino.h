#pragma once
#include <string>
#include <vector>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <atomic>
#include <functional>
#include <initializer_list>
#include <cctype>
#include <stdarg.h>
class String {
public:
 std::string s;
 String(){}String(const char* x):s(x?x:""){}String(const std::string& x):s(x){}String(char c):s(1,c){}
 String(int x):s(std::to_string(x)){}String(unsigned x):s(std::to_string(x)){}String(long x):s(std::to_string(x)){}String(unsigned long x):s(std::to_string(x)){}String(long long x):s(std::to_string(x)){}String(unsigned long long x):s(std::to_string(x)){}
 size_t length()const{return s.size();}char operator[](int i) const{return s.at(i);}char& operator[](int i){return s.at(i);}const char* c_str()const{return s.c_str();}
 String substring(int a)const{return s.substr(a);}String substring(int a,int b)const{return s.substr(a,b-a);}int indexOf(const char* x,int a=0) const{auto p=s.find(x,a);return p==std::string::npos?-1:(int)p;}
 int indexOf(const String& x,int a=0)const{return indexOf(x.c_str(),a);}
 int indexOf(char x,int a=0) const{auto p=s.find(x,a);return p==std::string::npos?-1:(int)p;}
 long toInt()const{return std::atol(s.c_str());}void toLowerCase(){for(auto&x:s)x=tolower((unsigned char)x);}void reserve(size_t n){s.reserve(n);}void remove(int a){s.erase(a);}void remove(int a,int n){s.erase(a,n);}
 bool startsWith(const char* v)const{return s.rfind(v,0)==0;}bool startsWith(const String& v)const{return startsWith(v.c_str());}
 String& operator+=(char c){s.push_back(c);return *this;}String& operator+=(const String& x){s+=x.s;return *this;}
 friend String operator+(String a,const String& b){a+=b;return a;}
 friend bool operator==(const String& a,const String& b){return a.s==b.s;}friend bool operator!=(const String& a,const String& b){return a.s!=b.s;}
};
template<class A,class B>auto min(A a,B b)->decltype(a+b){return a<b?a:b;}
template<class A,class B>auto max(A a,B b)->decltype(a+b){return a>b?a:b;}
template<class A,class B,class C> A constrain(A v,B lo,C hi){return v<lo?(A)lo:(v>hi?(A)hi:v);}
inline uint32_t millis(){return 12345;}inline void delay(int){}inline long random(long x){return x?0:0;}inline uint32_t esp_random(){return 123456;}
struct SerialType{void begin(int){}template<typename...A>void printf(const char*,A...){}template<typename T>void println(T){} template<typename T>void print(T){}};inline SerialType Serial;
#define WIFI_STA 1
#define pdMS_TO_TICKS(x) (x)
using portMUX_TYPE=int;
#define portMUX_INITIALIZER_UNLOCKED 0
inline void portENTER_CRITICAL(portMUX_TYPE*){}inline void portEXIT_CRITICAL(portMUX_TYPE*){}
inline void vTaskDelay(int){}
inline void xTaskCreatePinnedToCore(void (*)(void*),const char*,int,void*,int,void*,int){}
