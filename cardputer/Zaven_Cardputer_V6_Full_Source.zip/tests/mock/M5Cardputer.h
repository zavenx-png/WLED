#pragma once
#include "Arduino.h"
// KEY_ESCAPE intentionally absent: not defined by the user's M5Cardputer library.
#define KEY_BACKSPACE 8
#define KEY_TAB 9
class M5Canvas;
struct DisplayClass{
 int rotation=0;void setRotation(int r){rotation=r;}void setBrightness(int){}void fillScreen(int){}
 void print(const char*){}int width(){return (rotation&1)?240:135;}int height(){return (rotation&1)?135:240;}
};
class M5Canvas{public:
 explicit M5Canvas(DisplayClass*){}
 void setColorDepth(int){}void* createSprite(int,int){return this;}void deleteSprite(){}
 void setTextFont(int){}void setTextSize(int){}void setTextColor(int,int){}void setCursor(int,int){}
 void print(const String&){}void fillScreen(int){}void fillRect(int,int,int,int,int){}
 void fillCircle(int,int,int,int){}void drawCircle(int,int,int,int){}
 void drawRoundRect(int,int,int,int,int,int){}void fillRoundRect(int,int,int,int,int,int){}
 void pushSprite(int,int){};
};
struct KeyboardState{bool fn=false,tab=false,del=false,enter=false;std::vector<char> word;};
struct KeyboardType{KeyboardState keysState(){return {};};bool isKeyPressed(char){return false;}bool isChange(){return false;}bool isPressed(){return false;}};
struct PowerType{int getBatteryLevel(){return 80;}int getBatteryVoltage(){return 3800;}};
struct CardputerType{DisplayClass Display;KeyboardType Keyboard;PowerType Power;void begin(int,bool){}void update(){}};
inline CardputerType M5Cardputer;
struct M5Type{int config(){return 0;}};inline M5Type M5;
