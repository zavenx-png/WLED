#!/usr/bin/env python3
from pathlib import Path
import tempfile,subprocess
src=Path(__file__).resolve().parents[1]/'WLED_HARNESS_PATCH/install_protocol_v2.py'
original='''// marker: previous animations, effects and LED map
// STOPWATCH ESP-NOW REMOTE PROTOCOL V1
#if defined(ARDUINO_ARCH_ESP32)
static int x=0;
#endif
/////////////////
//  UserMod Class  //
/////////////////////
class UserFxUsermod {
 bool onEspNowMessage(uint8_t* sender, uint8_t* payload, uint8_t len) override {
    if (len != 12U || memcmp(payload,"ZHR1",4) != 0) return false;
    if (payload[4] != 1U || !zh_radio_is_paired(sender)) return true;
    portENTER_CRITICAL(&zh_radio_mux);
    memcpy(zh_radio_sender,sender,6);
    memcpy(zh_radio_packet,payload,12);
    zh_radio_pending=true;
    portEXIT_CRITICAL(&zh_radio_mux);
    return true; // This is our command, don't interpret it as WiZmote or sync.
 }
};
// marker: last usermod effect registration
'''
with tempfile.TemporaryDirectory() as d:
 root=Path(d);file=root/'usermods/user_fx/user_fx.cpp';file.parent.mkdir(parents=True)
 file.write_text(original)
 p=subprocess.run(['python3',str(src)],cwd=root,text=True,capture_output=True)
 assert p.returncode==0,p.stderr+p.stdout
 patch=file.read_text()
 assert 'ZAVEN ESP-NOW V2 / ZHR2' in patch
 assert 'const bool v2=(len==16U' in patch
 assert '// marker: previous animations' in patch
 assert '// marker: last usermod effect registration' in patch
 assert file.with_suffix('.cpp.before_zaven_v2').read_text()==original
 p=subprocess.run(['python3',str(src)],cwd=root,text=True,capture_output=True)
 assert p.returncode!=0 and 'Already patched' in p.stderr+p.stdout
print('WLED patch installer integration and rollback-backup tests passed')
