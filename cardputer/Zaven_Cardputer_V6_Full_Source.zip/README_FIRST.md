# ZAVEN STUDIOS — Festival Kit V6 ESP-NOW First

**Two-part source release:** (1) Cardputer ADV V6 firmware and (2) a matching ESP-NOW V2 patch for your custom WLED harness branch `harness-espnow-five-meteors` in `zavenx-png/WLED`.

**IMPORTANT — source release, not flash-ready binaries.** The Arduino and WLED toolchains are not installed in this environment. Native C++ syntax/behavior tests pass; neither final firmware has been compiled with the actual board toolchains nor tested on hardware. Keep your last working binaries and WLED configuration backup.

## How it works

- **Normal power-on:** Cardputer starts ESP-NOW immediately, probes the previously working channel, and scans channels 1–11 until a paired WLED controller acknowledges. **It does not join `WLED-AP`, `Harness-AP`, a home router, or the internet for regular control.**
- **One-time catalog sync:** On the first boot **without a saved catalog**, it makes a single Wi-Fi connection attempt to the AP in Profile 1 (default `Harness-AP`). It downloads effects, metadata, existing saved preset names/IDs, palettes and actual five-color previews; saves to `/ZAVEN_V6/catalog.bin` on the Cardputer microSD; then disconnects Wi-Fi and resumes ESP-NOW. If sync fails, normal radio controls remain available and `K` retries manually.
- **Subsequent boots:** Reads the catalog from microSD. **No repeated Wi-Fi attempts.** `K` or Menu → Refresh WLED catalog triggers a deliberate one-time Wi-Fi sync after changes to WLED effects, presets, or palettes.
- **ESP-NOW radio controls:** V2 carries effect change, WLED palette selection, brightness, preset recall, power, speed, intensity, custom 1–3 and effect options 1–3. V2 acknowledgments return current effect, palette, preset, settings and brightness, allowing live state display without an IP network.
- **Old harness compatibility:** The new WLED receiver still recognizes old `ZHR1`/`ZHA1` messages. The Cardputer can use legacy V1 power/preset/brightness if an older receiver is found. **Effect and palette controls require the matching new V2 harness firmware.**

**microSD is required for persistent complete catalog storage.** This is the same card used by M5Launcher. The catalog is keyed to the chosen AP SSID. If the card is missing, the metadata can be loaded into RAM but will not survive reboot.

## What remains intentionally Wi-Fi / WLED API based

The following **administrative operations** require a temporary, explicit Wi-Fi session: creating a named WLED preset, renaming/duplicating presets, playlist authoring, and live LED sample downloads. They use the existing WLED JSON/presets API to avoid unsafe direct filesystem writes from an ESP-NOW receiver. After each administrative operation the Cardputer disconnects Wi-Fi, refreshes its microSD cache, and returns to ESP-NOW. The normal festival controls do not need any of these sessions.

A stale cached catalog retains the previous WLED names until you press `K` and sync again. The radio-reported *actual* WLED effect/preset IDs and settings remain current.

## Installation order — VERY IMPORTANT

### A. WLED harness (do this first)

1. Back up your harness's WLED configuration, presets and current working firmware. Make sure you have a rollback path.
2. Work in a local checkout of your **existing custom WLED repository**, not the upstream standard WLED repository. Check out branch `harness-espnow-five-meteors`, then make a new local branch for V2:

   ```bash
   git checkout harness-espnow-five-meteors
   git checkout -b festival-kit-v6-espnow-v2
   ```

3. Put `WLED_HARNESS_PATCH/install_protocol_v2.py` anywhere on your Mac. From the **root of the WLED repository**, run:

   ```bash
   python3 /path/to/install_protocol_v2.py
   ```

4. The patch only modifies `usermods/user_fx/user_fx.cpp`, creates `usermods/user_fx/user_fx.cpp.before_zaven_v2`, and retains all custom LED animations, mappings and other files. Review `git diff` before committing. The patch **refuses** to modify unexpected versions of the source.
5. Build your harness firmware using the **same PlatformIO environment / GitHub Actions workflow you used for the currently working custom harness**. Confirm the build succeeds before flashing. Do not use a generic WLED binary: it lacks your mappings and V2 receiver.
6. Flash the new WLED binary to your harness. In WLED → Config → WiFi Setup, confirm **Enable ESP-NOW** is on and your **Cardputer STA MAC address** is in the Remote List. Preserve your original WLED AP name `Harness-AP`.
7. Make sure `Harness-AP` is available for the one-time sync, e.g. AP mode **Always** if supported by your WLED settings.

If the WLED source fails to compile, **do not flash it**. The custom branch may have changes relative to the code this patch targets.

### B. Cardputer ADV

1. Open `Zaven_Festival_Kit_V6/Zaven_Festival_Kit_V6.ino` in Arduino IDE; keep the accompanying `V6_*.h` files in the same sketch directory.
2. Select **M5Stack → M5Cardputer**. If you see `Missing FQBN`, select the board explicitly.
3. Under **Tools → Partition Scheme**, select **Huge APP (3MB No OTA / 1MB SPIFFS)** or an equivalent large-app profile (the original V6 is larger than the default 1.31 MB application limit). This is needed for **compilation**; M5Launcher handles application slots separately.
4. Click **Verify**. Once the source compiles, use **Sketch → Export Compiled Binary** and copy the *application* `.ino.bin` onto microSD `/firmware/`.
5. Install the binary with **M5Launcher**. Do not use a merged/bootloader/partitions binary as an application.
6. Reinsert the microSD. Power on harness first, then Cardputer. Watch **I → Diagnostics** for `ESP-NOW SYNCED`, `ZHR2 READY`, and the radio channel.
7. If the catalog isn't already cached, the Cardputer attempts a **single** sync to `Harness-AP`. Set Profile 1's AP password using **W → 2** if needed, then press **K** to retry. The direct AP gateway is normally `4.3.2.1`; `192.168.1.4` is likely the router-side IP and does not belong in the direct-AP Host field.
8. Once the catalog is stored, reboot the Cardputer. It should control the harness over ESP-NOW with **Wi-Fi OFF**, while names, presets and palette previews are available from microSD.

### If the screen shows NO ACK

- Check WLED's `Enable ESP-NOW` toggle and WLED's paired Remote List MAC.
- Press `T` for ping and open `I` for diagnostics. A full channel scan can take approximately 5 seconds; do not assume a missing AP is the problem.
- If `ZHR1 - UPGRADE HARNESS` appears, the Cardputer found the **old** receiver. Install the matched WLED V2 firmware to unlock effect/palette/settings control.
- If Wi-Fi catalog sync fails, connect a phone or Mac to `Harness-AP`, open the AP gateway address, then check the AP password and Profile 1 SSID. This is independent of the ESP-NOW radio link.

### Rollback

Keep the previous Cardputer binary on M5Launcher SD and the previous harness WLED binary backed up. If anything is unstable, restore the previous firmware on the affected device; the new protocol retains V1 compatibility, but two-way V2 controls require both updated sides.

## Build/test limitations

Local checks compile the Cardputer against native mock interfaces and test the packet format and state parsing; the WLED protocol implementation compiles against simulated WLED types and passes command/ACK tests. These are **not substitutes for the real M5Stack Arduino build, WLED PlatformIO build, or hardware validation**. Follow `TEST_REPORT.md` and test gradually before relying on this at a festival.
