/*
  ZAVEN STUDIOS  /  FESTIVAL KIT V6
  Cardputer ADV + paired WLED harness

  One source sketch, with all implementation in the included .h files.
  Arduino IDE: Board "M5Cardputer", M5Stack board package >=3.2.3,
  M5Cardputer library >=1.1.1 (plus its M5Unified/M5GFX dependencies).

  No ArduinoJson/WebSockets dependencies. Requires matched WLED ZHR2 harness firmware patch.
  Existing ESP-NOW ZHR1/ZHA1 packets are preserved.

  IMPORTANT: V6 has not yet been compiled on a Cardputer ADV in this environment.
  Read README_FIRST.md before replacing your working firmware.
*/
#include "V6_UI.h"
void setup() { FK6::begin(); }
void loop()  { FK6::tick(); }
