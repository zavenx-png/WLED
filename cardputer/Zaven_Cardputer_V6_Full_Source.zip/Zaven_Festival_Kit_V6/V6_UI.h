#pragma once
#include "V6_Network.h"
namespace FK6 {
enum Page:uint8_t {HOME=0,PALETTE_PAGE,FX_PAGE,PRESET_PAGE,SETTINGS_PAGE,MENU_PAGE,HELP_PAGE,
 BRIGHT_PAGE,DIAG_PAGE,BATTERY_PAGE,WIFI_PAGE,EDITOR_PAGE,CONFIRM_PAGE,ROTATE_PAGE,
 PROFILE_PAGE,LIVE_PAGE,LOCK_PAGE,PLAYLIST_PAGE,ABOUT_PAGE};
enum Filter:uint8_t {ALL_FX=0,Z_FX,FAVORITE_FX,RECENT_FX};
enum EditType:uint8_t {EDIT_NONE=0,EDIT_SEARCH,EDIT_SSID,EDIT_PASS,EDIT_HOST,EDIT_PRESET_NAME,EDIT_RENAME};
enum ConfirmType:uint8_t {CONFIRM_NONE=0,CONFIRM_SAVE,CONFIRM_OVERWRITE,CONFIRM_DUP,CONFIRM_PLAY,CONFIRM_RENAME,CONFIRM_RESTORE};
struct App {
 Page page=HOME,lastPage=HOME;
 uint8_t filter=ALL_FX,menuIndex=0,helpIndex=0,fxRow=0,presetRow=0,paletteRow=0,paramRow=0,profileRow=0;
 int selectedFx=-1,selectedPreset=-1,selectedPal=-1;
 bool locked=false,autoRotate=false,randomRotate=false,dimScreen=false,livePreviewSupported=false,onlyFavPalettes=false;
 bool showToast=false,haveUndo=false;uint8_t bank=0;
 uint8_t brightness=120,screenLight=80,rotationSeconds=20,rotateScope=1;
 int direction=0,holdDirection=0;uint32_t holdStarted=0,lastStep=0;
 uint32_t overlayAt=0,lastInputAt=0,lastRender=0,lastRotateAt=0,lastToastAt=0,lastScanMonitor=0;
 uint32_t lastRadioIndicator=0,lastStateSeen=0;
 int lastFX=-1; DeviceState undo;
 String search="",editText="",toast="";
 uint8_t editType=0,confirmType=0;
 uint16_t confirmedPresetID=0;int duplicateFrom=0;
 uint16_t recent[16]={0};uint8_t recentCount=0;
 uint8_t favoriteBank[3][32]={};
 uint8_t paletteFavorite[32]={};
 uint8_t playlistIds[16]={};uint8_t playlistCount=0;int playlistRow=0;
 bool performanceLock=false;
 uint32_t lockHold=0,liveAt=0,tapAt=0;int bpm=125;
 uint8_t playlistDuration=30,playlistTransition=3;
 int cacheGeneration=0;int lastSeenFx=-1,lastSeenPs=-1;
};
static App app;
static M5Canvas canvas(&M5Cardputer.Display);
static bool spriteOK=false,dirty=true;


static void storeBank(){
 prefs.putBytes("fb0",app.favoriteBank[0],32);
 prefs.putBytes("fb1",app.favoriteBank[1],32);
 prefs.putBytes("fb2",app.favoriteBank[2],32);
 prefs.putUChar("bank",app.bank);
}
static bool isFav(int id){if(id<0||id>=MAX_FX)return false;
 return (app.favoriteBank[app.bank][id/8]>>(id%8))&1;
}
static void toggleFav(int id){if(id<0||id>=MAX_FX)return;
 app.favoriteBank[app.bank][id/8]^=1<<(id%8);storeBank();dirty=true;
}
static void recordRecent(int id){if(id<0||id>=MAX_FX)return;
 int found=-1;for(int i=0;i<app.recentCount;i++)if(app.recent[i]==id)found=i;
 if(found>=0)for(int i=found;i+1<app.recentCount;i++)app.recent[i]=app.recent[i+1];
 else if(app.recentCount<16)app.recentCount++;
 for(int i=app.recentCount-1;i>0;i--)app.recent[i]=app.recent[i-1];
 app.recent[0]=id;
}
static void say(const String& s){app.toast=s;app.lastToastAt=millis();app.showToast=true;dirty=true;}
static void goHome(){app.page=HOME;app.editType=EDIT_NONE;app.confirmType=CONFIRM_NONE;
 app.lastInputAt=millis();dirty=true;}
static void openPage(Page p){app.lastPage=app.page;app.page=p;app.lastInputAt=millis();dirty=true;}
static int filteredFxCount(){const Catalog* c=activeCatalog.load();if(!c)return 0;
 int n=0;for(int i=0;i<c->fxCount;i++){
  if(!validFx(c->fx[i]))continue;
  if(app.filter==Z_FX&&!isZ(c->fx[i]))continue;
  if(app.filter==FAVORITE_FX&&!isFav(i))continue;
  if(app.filter==RECENT_FX){bool recent=false;for(int k=0;k<app.recentCount;k++)if(app.recent[k]==i)recent=true;if(!recent)continue;}
  if(!containsCI(c->fx[i],app.search))continue;
  n++;
 }return n;
}
static int filteredFxAt(int rank){const Catalog* c=activeCatalog.load();if(!c||rank<0)return -1;
 int n=0;for(int i=0;i<c->fxCount;i++){
  if(!validFx(c->fx[i]))continue;
  if(app.filter==Z_FX&&!isZ(c->fx[i]))continue;
  if(app.filter==FAVORITE_FX&&!isFav(i))continue;
  if(app.filter==RECENT_FX){bool recent=false;for(int k=0;k<app.recentCount;k++)if(app.recent[k]==i)recent=true;if(!recent)continue;}
  if(!containsCI(c->fx[i],app.search))continue;
  if(n++==rank)return i;
 }return -1;
}
static int nextEffect(int from,int direction,bool zOnly){const Catalog* c=activeCatalog.load();if(!c||!c->fxCount)return -1;
 int n=c->fxCount;int at=from;if(at<0||at>=n)at=direction>0?n-1:0;
 for(int i=0;i<n;i++){at=(at+direction+n)%n;
  if(validFx(c->fx[at])&&(!zOnly||isZ(c->fx[at])))return at;
 }return -1;
}
static String quotedEffectName(int fx){return getFxLabel(activeCatalog.load(),fx);}
static void changeEffect(int fx){const Catalog* c=activeCatalog.load();if(!c||fx<0||fx>=c->fxCount)return;
 if(!v2Capable.load()){say("V2 harness link required");return;}
 DeviceState st=getDevice();app.undo=st;app.haveUndo=true;app.lastFX=st.fx;
 app.selectedFx=fx;app.selectedPreset=-1;recordRecent(fx);
 if(!v2Capable.load()){say("Need V2 harness ESP-NOW link");return;}
 if(!remoteControl(6,(uint16_t)fx)){say("ESP-NOW command not sent");return;}
 else say(getFxLabel(c,fx));
 app.lastRotateAt=millis();dirty=true;
}
static void stepFx(int dir,bool zOnly){int current=app.selectedFx;
 if(current<0)current=getDevice().fx;
 int next=nextEffect(current,dir,zOnly);
 if(next>=0)changeEffect(next);
 else say("Catalog unavailable");
}
static bool haveRecentAck(){return ackTime.load()!=0&&millis()-ackTime.load()<LINK_TIMEOUT;}
static void recallPreset(int id){if(id<1||id>250)return;
 const Catalog* c=activeCatalog.load();app.selectedPreset=id;
 app.selectedFx=-1;app.lastRotateAt=millis();
 bool sent=remoteControl(1,(uint16_t)id,0,1,(uint8_t)id);
 say(sent?getPresetLabel(c,id):"No ESP-NOW link");dirty=true;
}
static void useQuick(int pos){const Catalog* c=activeCatalog.load();if(!c||pos<0||pos>=10){say("Waiting for preset catalog");return;}
 int id=c->quickSlots[pos];if(id<=0){say("No saved preset in this slot");return;}
 recallPreset(id);
}
static void togglePower(){bool ok=remoteControl(3,0,0,3);
 say(ok?"Power toggle sent":"No ESP-NOW radio");}
static void blackout(){bool ok=remoteControl(5,0,0,5);
 say(ok?"BLACKOUT sent":"No ESP-NOW radio");}
static void setBrightnessStep(int dir){
 if(app.page!=BRIGHT_PAGE){app.brightness=getDevice().bri;openPage(BRIGHT_PAGE);}
 app.brightness=constrain((int)app.brightness+dir*6,1,255);
 app.overlayAt=millis();
 if(!remoteControl(2,app.brightness,0,2,app.brightness))say("Brightness not sent");
 dirty=true;
}
static bool isFavoritePalette(int pal);
static int visiblePaletteCount(){const Catalog* c=activeCatalog.load();if(!c)return 0;
 if(!app.onlyFavPalettes)return c->palCount;
 int n=0;for(int i=0;i<c->palCount;i++)if(isFavoritePalette(c->palOrder[i]))n++;
 return n;
}
static int paletteAtRow(int row){const Catalog* c=activeCatalog.load();if(!c||row<0)return -1;
 for(int i=0;i<c->palCount;i++){int id=c->palOrder[i];
  if(app.onlyFavPalettes&&!isFavoritePalette(id))continue;
  if(row--==0)return id;
 }return -1;
}
static void selectPalette(int idx){int n=visiblePaletteCount();if(n<1)return;
 app.paletteRow=constrain(idx,0,n-1);
 int pal=paletteAtRow(app.paletteRow);if(pal<0)return;
 app.selectedPal=pal;palettePageRequest.store(pal/8);dirty=true;
}
static void showPalettePicker(){
 int row=0,shown=visiblePaletteCount(),current=getDevice().pal;
 for(int i=0;i<shown;i++)if(paletteAtRow(i)==current){row=i;break;}
 if(shown)selectPalette(row);
 openPage(PALETTE_PAGE);
}
static void applyPalette(){const Catalog* c=activeCatalog.load();if(!c||visiblePaletteCount()==0)return;
 int pal=paletteAtRow(app.paletteRow);
 if(!v2Capable.load()){say("Need V2 harness ESP-NOW link");return;}
 if(remoteControl(7,(uint16_t)pal)){app.selectedPal=pal;goHome();say(String("PALETTE: ")+c->pal[pal].name);}
}
static void undoEffect(){if(!app.haveUndo){say("Nothing to restore");return;}
 DeviceState u=app.undo;String json=segmentPatch(u.mainseg,
  "\"fx\":"+String(u.fx)+",\"sx\":"+String(u.sx)+",\"ix\":"+String(u.ix)+
  ",\"pal\":"+String(u.pal)+",\"c1\":"+String(u.c1)+",\"c2\":"+String(u.c2)+
  ",\"c3\":"+String(u.c3)+",\"o1\":"+String(u.options[0]?"true":"false")+
  ",\"o2\":"+String(u.options[1]?"true":"false")+
  ",\"o3\":"+String(u.options[2]?"true":"false"));
 bool ok=v2Capable.load()&&remoteControl(6,(uint16_t)u.fx);
 if(ok){
   // The harness receiver queues these commands, avoiding lost burst controls.
   remoteControl(9,u.sx,0);remoteControl(9,u.ix,1);
   remoteControl(7,u.pal);
   remoteControl(9,u.c1,2);remoteControl(9,u.c2,3);remoteControl(9,u.c3,4);
   remoteControl(9,u.options[0],5);remoteControl(9,u.options[1],6);
   remoteControl(9,u.options[2],7);
   app.selectedFx=u.fx;app.haveUndo=false;say("Previous effect restored");
 }else say("V2 radio link required for undo");
}
static int nextFreePreset(){const Catalog* c=activeCatalog.load();if(!c)return -1;
 for(int i=1;i<=MAX_PRESETS;i++)if(!c->preset[i].exists)return i;
 return -1;
}
static void beginSavePreset(){
 int id=nextFreePreset();if(id<0){say("Preset list full");return;}
 app.confirmedPresetID=id;app.editType=EDIT_PRESET_NAME;
 app.editText="V6 - "+quotedEffectName(getDevice().fx);if(app.editText.length()>52)app.editText.remove(52);
 openPage(EDITOR_PAGE);
}
static void openSearch(){app.editType=EDIT_SEARCH;app.editText=app.search;openPage(EDITOR_PAGE);}
static void beginProfileEdit(uint8_t type){app.editType=type;
 Profile p;portENTER_CRITICAL(&profileMux);p=profiles[app.bank>=3?0:profileIndex.load()];portEXIT_CRITICAL(&profileMux);
 if(type==EDIT_SSID)app.editText=p.ssid;
 else if(type==EDIT_PASS)app.editText=p.password;
 else if(type==EDIT_HOST)app.editText=p.host;
 else app.editText="";
 openPage(EDITOR_PAGE);
}
static void saveProfiles(){for(int i=0;i<3;i++){
  String prefix="p"+String(i);
  prefs.putString((prefix+"ss").c_str(),profiles[i].ssid);
  prefs.putString((prefix+"pw").c_str(),profiles[i].password);
  prefs.putString((prefix+"ip").c_str(),profiles[i].host);
 }prefs.putUChar("profile",profileIndex.load());
}
static void finishEditor(){
 if(app.editType==EDIT_SEARCH){app.search=app.editText;app.fxRow=0;app.page=FX_PAGE;}
 else if(app.editType==EDIT_PRESET_NAME){app.confirmType=CONFIRM_SAVE;app.page=CONFIRM_PAGE;}
 else if(app.editType==EDIT_RENAME){app.confirmType=CONFIRM_RENAME;app.page=CONFIRM_PAGE;}
 else if(app.editType==EDIT_SSID||app.editType==EDIT_PASS||app.editType==EDIT_HOST){
   int p=profileIndex.load();p=constrain(p,0,2);
   portENTER_CRITICAL(&profileMux);
   if(app.editType==EDIT_SSID)cpy(profiles[p].ssid,sizeof(profiles[p].ssid),app.editText);
   if(app.editType==EDIT_PASS)cpy(profiles[p].password,sizeof(profiles[p].password),app.editText);
   if(app.editType==EDIT_HOST)cpy(profiles[p].host,sizeof(profiles[p].host),app.editText);
   portEXIT_CRITICAL(&profileMux);
   saveProfiles();profileChange.store(1);app.page=PROFILE_PAGE;
   say("Network saved / reconnecting");
 }
 app.editType=EDIT_NONE;dirty=true;
}
static bool isFavoritePalette(int pal){return pal>=0&&pal<256&&(app.paletteFavorite[pal/8]>>(pal%8)&1);}
static void togglePaletteFavorite(int pal){if(pal<0||pal>=256)return;
 app.paletteFavorite[pal/8]^=1<<(pal%8);prefs.putBytes("palfav",app.paletteFavorite,32);
 say(isFavoritePalette(pal)?"Saved favorite palette":"Removed favorite palette");
}
static void cycleBank(){app.bank=(app.bank+1)%3;storeBank();say("Favorite bank "+String((int)app.bank+1));}
static void rotateStep(){const Catalog* c=activeCatalog.load();if(!c)return;
 if(app.rotateScope==3&&c->presetCount>0){
  int found=-1;for(int i=0;i<c->presetCount;i++)if(c->presetOrder[i]==app.selectedPreset)found=i;
  int next=(found+1)%c->presetCount;if(app.randomRotate)next=random(c->presetCount);
  recallPreset(c->presetOrder[next]);return;
 }
 if(app.rotateScope==2)app.filter=FAVORITE_FX;
 else if(app.rotateScope==1)app.filter=Z_FX;
 else app.filter=ALL_FX;
 int cur=app.selectedFx>=0?app.selectedFx:getDevice().fx;
 if(app.randomRotate){int count=filteredFxCount();if(count>0)changeEffect(filteredFxAt(random(count)));}
 else{int v=nextEffect(cur,1,app.rotateScope==1);
  if(app.rotateScope==2){int at=cur;for(int i=0;i<MAX_FX;i++){at=nextEffect(at,1,false);if(at>=0&&isFav(at)){v=at;break;}}}
  if(v>=0)changeEffect(v);
 }
}
static const char* menuNames[]={"ALL EFFECTS","Z EFFECTS","FAVORITES","RECENT EFFECTS","PRESET LIBRARY",
 "WLED PALETTES","EFFECT SETTINGS","SAVE NEW PRESET","AUTO ROTATION","PLAYLIST",
 "DEVICE PROFILES","RADIO DIAGNOSTICS","BATTERY / DISPLAY","LIVE LED PREVIEW","BACKUP TO MICROSD",
 "SEARCH EFFECTS","HELP / KEY MAP","ABOUT V6",
 "RESTORE SD SETTINGS","REFRESH WLED CATALOG"};
static const int menuCount=sizeof(menuNames)/sizeof(menuNames[0]);
static void menuSelect(int index){switch(index){
  case 0:app.filter=ALL_FX;app.search="";app.fxRow=0;openPage(FX_PAGE);break;
  case 1:app.filter=Z_FX;app.search="";app.fxRow=0;openPage(FX_PAGE);break;
  case 2:app.filter=FAVORITE_FX;app.search="";app.fxRow=0;openPage(FX_PAGE);break;
  case 3:app.filter=RECENT_FX;app.search="";app.fxRow=0;openPage(FX_PAGE);break;
  case 4:app.presetRow=0;openPage(PRESET_PAGE);break;
  case 5:showPalettePicker();break;
  case 6:app.paramRow=0;openPage(SETTINGS_PAGE);break;
  case 7:beginSavePreset();break;
  case 8:openPage(ROTATE_PAGE);break;
  case 9:openPage(PLAYLIST_PAGE);break;
  case 10:openPage(PROFILE_PAGE);break;
  case 11:openPage(DIAG_PAGE);break;
  case 12:openPage(BATTERY_PAGE);break;
  case 13:openPage(LIVE_PAGE);say("Preview: K sync Wi-Fi to sample");break;
  case 14:{// handled in confirm step of file write
    app.confirmType=CONFIRM_OVERWRITE;openPage(CONFIRM_PAGE);break;}
  case 15:openSearch();break;
  case 16:app.helpIndex=0;openPage(HELP_PAGE);break;
  case 17:openPage(ABOUT_PAGE);break;
  case 18:{app.confirmType=CONFIRM_RESTORE;openPage(CONFIRM_PAGE);break;}
  case 19:syncRequested.store(true);say("One-time Wi-Fi catalog sync");goHome();break;
 }}
}
namespace FK6 {
// 240x135 layout, 16bpp off-screen framebuffer, no periodic screen clear.
static void put(int x,int y,const String& s,uint16_t color=TEXT,int scale=1){
 canvas.setTextFont(1);canvas.setTextSize(scale);canvas.setTextColor(color,BG);
 canvas.setCursor(x,y);canvas.print(s);
}
static String shorten(String s,int chars){if((int)s.length()<=chars)return s;if(chars<4)return s.substring(0,chars);
 return s.substring(0,chars-2)+"..";}
static void linesLarge(const String& s,int top=51,int maxRows=3){
 // Preserve the full stored WLED name and the initial "Z -".
 int at=0,len=s.length();if(len<1){put(9,top,"SELECT A PRESET",TEXT,2);return;}
 for(int row=0;row<maxRows&&at<len;row++){
  int cap=19,end=min(len,at+cap);
  if(end<len){int space=-1;for(int p=end-1;p>at+8;--p){if(s[p]==' '){space=p;break;}}
    if(space>0)end=space;
  }
  String chunk=s.substring(at,end);
  put(9,top+row*22,chunk,TEXT,2);
  at=end;while(at<len&&s[at]==' ')++at;
 }
 if(at<len){ // Extremely long names: last line at readable 1x rather than cut away.
  put(9,top+maxRows*22-2,shorten(s.substring(at),38),FAINT,1);
 }
}
static void frameBase(const String& title=""){
 canvas.fillScreen(BG);canvas.fillRect(0,0,240,23,PANEL);
 put(4,3,"ZAVEN STUDIOS",TEXT,2);
 uint32_t ack=ackTime.load();bool live=espReady.load()&&ack&&millis()-ack<LINK_TIMEOUT;
 canvas.fillCircle(171,11,3,live?GREEN:(espReady.load()?AMBER:ALERT));
 put(178,4,live?"SYNC":"WAIT",live?GREEN:AMBER,1);
 put(211,4,"C"+String(radioChannel.load()),ACCENT,1);
 if(title.length())put(8,28,title,PINK,1);
}
static void bottomLabel(const String& s,uint16_t color=SUBTLE){
 canvas.fillRect(0,119,240,16,PANEL);
 int scale=s.length()<=18?2:1;put(5,scale==2?119:123,shorten(s,scale==2?18:37),color,scale);
}
static bool apiAlive(){uint32_t ms=lastSync.load();return wifiOnline.load()&&ms&&millis()-ms<9000;}
static void renderHome(){
 DeviceState st=getDevice();const Catalog* c=activeCatalog.load();
 String name="CONNECTING TO HARNESS";
 if(c&&catReady.load()){
  if(app.selectedPreset>=1)name=getPresetLabel(c,app.selectedPreset);
  else if(app.selectedFx>=0)name=getFxLabel(c,app.selectedFx);
  else if(st.ps>=1)name=getPresetLabel(c,st.ps);
  else name=getFxLabel(c,st.fx);
 }else {name="SYNC WLED CATALOG";}
 put(9,30,app.selectedPreset>=0?"WLED PRESET": "WLED EFFECT",PINK,1);
 if(c&&catReady.load())put(150,30,app.selectedPreset>=0?"#"+String(app.selectedPreset):"FX "+String(app.selectedFx>=0?app.selectedFx:st.fx),ACCENT,1);
 linesLarge(name,53,3);
 if(app.showToast&&millis()-app.lastToastAt<1400)bottomLabel(app.toast,AMBER);
 else bottomLabel(syncInProgress.load()?"WIFI: SYNCING CATALOG":
  (catReady.load()?"CATALOG SAVED / ESP-NOW":"PRESS K: SYNC CATALOG"),
  catReady.load()?GREEN:AMBER);
}
static void renderPalette(){const Catalog* c=activeCatalog.load();int n=visiblePaletteCount();
 put(8,29,"WLED COLOR PALETTES",PINK,1);
 if(!n){put(10,56,app.onlyFavPalettes?"NO FAVORITE PALETTES":"CONNECT TO WLED",TEXT,1);bottomLabel("V: ALL PALETTES",AMBER);return;}
 int idx=constrain((int)app.paletteRow,0,n-1),palId=paletteAtRow(idx);
 const Palette& p=c->pal[palId];
 put(181,29,String(idx+1)+"/"+String(n),FAINT,1);
 String label(p.name);if(isFavoritePalette(palId))label="* "+label;
 if(label.length()<=19)put(10,50,label,TEXT,2);
 else {int cut=min((int)label.length(),19);for(int k=cut-1;k>9;k--)if(label[k]==' '){cut=k;break;}
  put(10,43,label.substring(0,cut),TEXT,2);
  put(10,63,shorten(label.substring(cut),19),TEXT,2);
 }
 int y=label.length()>19?102:89;
 for(int i=0;i<5;i++){
  int x=29+i*46;
  canvas.fillCircle(x,y,13,PANEL2);
  canvas.fillCircle(x,y,10,p.preview?p.dot[i]:SUBTLE);
  canvas.drawCircle(x,y,11,TEXT);
 }
 bottomLabel(p.preview?"ENTER: APPLY  F: SAVE FAVORITE":"ENTER: APPLY  |  DYNAMIC COLOR",p.preview?GREEN:AMBER);
}
static void renderBrowser(){const Catalog* c=activeCatalog.load();
 const char* cat[]={"ALL EFFECTS","Z EFFECTS","FAVORITES","RECENT EFFECTS"};
 int count=filteredFxCount();put(8,29,String(cat[app.filter])+"  "+String(count),PINK,1);
 if(!count){put(10,62,c?"NO MATCHING EFFECTS":"CONNECT TO WLED",TEXT,1);
  bottomLabel("Q SEARCH  |  ESC BACK");return;}
 app.fxRow=constrain(app.fxRow,0,count-1);
 for(int k=-1;k<=1;k++){
  int row=app.fxRow+k;
  if(row<0||row>=count)continue;
  int id=filteredFxAt(row);
  String name=getFxLabel(c,id);int y=49+(k+1)*23;
  if(k==0){canvas.fillRoundRect(4,y-3,233,24,3,PANEL2);put(9,y,shorten(name,18),ACCENT,2);}
  else put(11,y+3,shorten(name,36),FAINT,1);
 }
 bottomLabel("ENTER: LOAD EFFECT  |  F FAVORITE",GREEN);
}
static void renderPresets(){const Catalog* c=activeCatalog.load();int n=c?c->presetCount:0;
 put(8,28,"SAVED WLED PRESETS",PINK,1);
 if(!n){put(8,60,"NO PRESETS SYNCED",TEXT,2);bottomLabel("Requires Wi-Fi catalog",AMBER);return;}
 app.presetRow=constrain(app.presetRow,0,n-1);
 for(int j=-1;j<=1;j++){
  int row=app.presetRow+j;if(row<0||row>=n)continue;
  int id=c->presetOrder[row];String name="#"+String(id)+" "+c->preset[id].name;
  int y=47+(j+1)*24;
  if(j==0){canvas.fillRoundRect(4,y-4,231,25,4,PANEL2);put(8,y,shorten(name,19),ACCENT,2);}
  else put(10,y+3,shorten(name,35),FAINT,1);
 }
 bottomLabel("ENTER: RECALL  |  1-0: FIRST 10",GREEN);
}
static const char* settingKeys[]={"sx","ix","c1","c2","c3","o1","o2","o3"};
static const char* settingDefaults[]={"Speed","Intensity","Custom 1","Custom 2","Custom 3","Option 1","Option 2","Option 3"};
static int settingLabels(int id,String labels[8],bool enabled[8]){
 for(int i=0;i<8;i++){labels[i]=settingDefaults[i];enabled[i]=(i<2);}
 const Catalog* c=activeCatalog.load();if(!c||id<0||id>=c->fxCount)return 2;
 String meta(c->metadata[id]);if(!meta.length())return 2;
 int section=meta.indexOf(';');String params=section>=0?meta.substring(0,section):meta;
 int at=params.indexOf('@');if(at>=0)params=params.substring(at+1);
 for(int i=0;i<8;i++)enabled[i]=false;
 int start=0;
 for(int i=0;i<8;i++){
  if(start>(int)params.length())break;
  int comma=params.indexOf(',',start);if(comma<0)comma=params.length();
  String token=params.substring(start,comma);
  if(token.length()&&token!="!"){enabled[i]=true;labels[i]=token;}
  start=comma+1;
 }
 int n=0;for(int i=0;i<8;i++)if(enabled[i])n++;return n;
}
static int settingIndexByRow(int row){String labels[8];bool enabled[8];settingLabels(getDevice().fx,labels,enabled);
 int index=0;for(int i=0;i<8;i++)if(enabled[i]&&index++==row)return i;return -1;
}
static int settingCount(){String labels[8];bool enabled[8];return settingLabels(getDevice().fx,labels,enabled);}
static int settingValue(const DeviceState& st,int index){switch(index){
 case 0:return st.sx;case 1:return st.ix;case 2:return st.c1;
 case 3:return st.c2;case 4:return st.c3;case 5:return st.options[0];
 case 6:return st.options[1];case 7:return st.options[2];default:return 0;}}
static void renderSettings(){DeviceState st=getDevice();const Catalog* c=activeCatalog.load();
 put(8,27,"EFFECT SETTINGS",PINK);
 put(8,40,shorten(getFxLabel(c,st.fx),35),FAINT);
 String labels[8];bool enabled[8];int n=settingLabels(st.fx,labels,enabled);
 if(!n){put(8,65,"NO ADJUSTABLE PARAMETERS",TEXT);bottomLabel("WLED effect metadata loaded");return;}
 app.paramRow=constrain(app.paramRow,0,n-1);
 int rowIdx=0;
 for(int i=0;i<8;i++)if(enabled[i]){
  int relative=rowIdx-(int)app.paramRow;
  if(relative>=-1&&relative<=1){int y=63+(relative+1)*20;
    if(relative==0){canvas.fillRoundRect(4,y-3,232,19,3,PANEL2);
      put(9,y,shorten(labels[i],19),ACCENT,1);
      put(193,y,(i>=5?(settingValue(st,i)?"ON":"OFF"):String(settingValue(st,i))),TEXT,1);
    }else put(11,y,shorten(labels[i]+"  "+String(settingValue(st,i)),34),FAINT,1);
  }rowIdx++;
 }
 bottomLabel("LEFT/RIGHT: ADJUST  ENTER: TOGGLE",GREEN);
}
static void renderMenu(){put(8,28,"CONTROL CENTER",PINK,1);
 int top=constrain((int)app.menuIndex-2,0,menuCount-5);
 for(int i=0;i<5;i++){
   int id=top+i;if(id>=menuCount)break;
   int y=44+i*15;
   if(id==app.menuIndex){canvas.fillRoundRect(5,y-2,229,15,3,PANEL2);put(9,y,shorten(menuNames[id],34),ACCENT,1);}
   else put(11,y,shorten(menuNames[id],34),TEXT,1);
 }
 bottomLabel("ENTER: OPEN  |  ESC: EFFECT SCREEN");
}
static const char* helpLines[3][7]={
 {"1-0  First ten WLED presets",", .  Previous/next all effects","[ ]  Previous/next Z effects","P  Power   X  Blackout","+ -  Brightness (hold to ramp)","C  WLED palette picker","Esc/Del  Main screen"},
 {"Tab  This key map (3 pages)","Arrows  ; , . / without Fn","Enter  Apply / open settings","B  Presets   M  All menus","Q  Search   F  Favorite FX","V  Favorites   R  Random","E  Effect-specific settings"},
 {"U  Tap BPM   A  Auto rotate","Z  Undo   L  Lock controls","I  Diagnostics  D  Battery","W  Wi-Fi profiles  T  Ping","S  Save current as preset","G  Browse all effects","H  Help /  Esc to return"}}
;
static void renderHelp(){put(8,28,"KEY MAP  "+String((int)app.helpIndex+1)+" / 3",PINK);
 for(int i=0;i<7;i++)put(9,43+i*11,helpLines[app.helpIndex][i],TEXT,1);
 bottomLabel("LEFT / RIGHT: HELP PAGES");
}
static void renderBrightness(){
 put(8,29,"HARNESS BRIGHTNESS",PINK,1);
 put(12,46,String((int)app.brightness*100/255)+"%",TEXT,3);
 put(137,54,String(app.brightness)+" / 255",ACCENT,1);
 canvas.drawRoundRect(8,93,210,22,5,TEXT);
 canvas.fillRect(219,100,11,8,TEXT);
 int w=(int)app.brightness*200/255;
 if(w>0)canvas.fillRoundRect(12,97,w,14,3,ACCENT);
 bottomLabel("ENTER: RETURN  |  AUTO: 3 SECONDS",FAINT);
}
static void renderDiag(){
 put(8,27,"RADIO / CONNECTION",PINK);
 put(8,41,String("ESP-NOW: ")+(ackTime.load()&&millis()-ackTime.load()<LINK_TIMEOUT?"SYNCED":"NO ACK"),TEXT);
 put(8,54,"RADIO CH: "+String(radioChannel.load())+"   RSSI: "+String(espRssi.load())+" dBm",ACCENT);
 put(8,67,"CATALOG: "+String(catReady.load()?"CACHED":"MISSING")+" WiFi "+
    String(syncInProgress.load()?"SYNC":"OFF"),TEXT);
 put(8,80,"TX "+String(sentPackets.load())+"  ACK "+String(ackPackets.load())+"  ERR "+String(errorCount.load()),TEXT);
 put(8,93,"PROTOCOL: "+String(v2Capable.load()?"ZHR2 READY":
  (legacyCapable.load()?"ZHR1 - UPGRADE HARNESS":"NO ACK YET")),TEXT);
 put(8,106,"LAST ACK: "+String(lastAckStatus.load())+"   TX: "+String(sentPackets.load()),FAINT);
 bottomLabel("T: PING  K: SYNC  W: WIFI");
}
static void renderBattery(){
 int percent=constrain(M5Cardputer.Power.getBatteryLevel(),0,100);
 int mv=M5Cardputer.Power.getBatteryVoltage();
 put(8,28,"CARDPUTER BATTERY",PINK);
 put(12,49,String(percent)+"%",TEXT,3);
 put(145,59,String(mv)+" mV",ACCENT);
 put(8,84,"SCREEN "+String(app.screenLight)+"  DIM "+String(app.dimScreen?"ON":"OFF"),FAINT);
 canvas.drawRoundRect(9,98,202,15,4,TEXT);
 canvas.fillRect(212,103,8,5,TEXT);
 int w=(int)percent*192/100;if(w>0)canvas.fillRoundRect(13,101,w,9,3,GREEN);
 bottomLabel("[ ]: SCREEN LIGHT  A: AUTO DIM");
}
static void renderWifi(){Profile p;portENTER_CRITICAL(&profileMux);p=profiles[profileIndex.load()];portEXIT_CRITICAL(&profileMux);
 put(8,27,"NETWORK PROFILE "+String(profileIndex.load()+1),PINK);
 put(8,44,"SSID "+shorten(String(p.ssid),31),TEXT);
 put(8,58,"HOST "+shorten(String(p.host[0]?p.host:"auto gateway"),31),TEXT);
 put(8,73,"CH "+String(radioChannel.load())+"    WiFi: "+
    String(syncInProgress.load()?"ONE-TIME SYNC":"OFF"),ACCENT);
 put(8,93,"1: SSID    2: PASSWORD",TEXT);
 put(8,108,"3: HOST    4: NEXT PROFILE",TEXT);
 bottomLabel("HOST BLANK = AUTO AP GATEWAY");
}
static void renderEditor(){put(8,28,"EDIT VALUE",PINK);
 const char* heads[]={"","SEARCH EFFECTS","WLED AP NAME","WLED AP PASSWORD","WLED HOST/IP","NEW PRESET NAME","RENAME WLED PRESET"};
 put(8,43,heads[constrain((int)app.editType,0,6)],FAINT);
 String value=app.editText;
 if(app.editType==EDIT_PASS){ // Password isn't shown on-screen for shoulder-surfing.
  value="";for(size_t i=0;i<app.editText.length();i++)value+='*';
 }
 put(8,64,shorten(value+"_",35),TEXT,1);
 put(8,90,"ENTER: SAVE",ACCENT);
 put(8,105,"BACKSPACE: ERASE",FAINT);
 bottomLabel("ESC: CANCEL   |   NO CAPS LIMIT",FAINT);
}
static void renderConfirm(){put(8,28,"CONFIRM ACTION",PINK);
 String msg;
 if(app.confirmType==CONFIRM_SAVE)msg="Save new preset #"+String(app.confirmedPresetID)+"?";
 else if(app.confirmType==CONFIRM_OVERWRITE)msg="Backup local settings to SD?";
 else if(app.confirmType==CONFIRM_DUP)msg="Duplicate selected preset?";
 else if(app.confirmType==CONFIRM_PLAY)msg="Run first ten presets?";
 else if(app.confirmType==CONFIRM_RESTORE)msg="Restore SD favorites/profiles?";
 else if(app.confirmType==CONFIRM_RENAME)msg="Recall and re-save preset #"+String(app.confirmedPresetID)+"?";
 put(9,52,shorten(msg,38),TEXT,1);
 put(9,77,"ENTER: YES",GREEN,2);
 put(9,103,"ESC: CANCEL",FAINT,1);
 bottomLabel("Presets will not change LED mapping");
}
static void renderRotation(){put(8,28,"AUTO ROTATION",PINK);
 put(8,45,String("STATUS: ")+(app.autoRotate?"RUNNING":"STOPPED"),app.autoRotate?GREEN:AMBER,1);
 const char* scopes[]={"ALL","Z EFFECTS","FAVORITES","PRESETS"};
 put(8,60,"SOURCE: "+String(scopes[constrain(app.rotateScope,0,3)]),TEXT,1);
 put(8,75,"INTERVAL: "+String(app.rotationSeconds)+" sec",TEXT);
 put(8,90,"MODE: "+String(app.randomRotate?"SHUFFLE":"SEQUENTIAL"),TEXT);
 put(8,105,"ENTER RUN / STOP   +/- TIME",ACCENT);
 bottomLabel("LEFT/RIGHT: SOURCE   R: SHUFFLE");
}
static void renderProfiles(){put(8,28,"THREE DEVICE PROFILES",PINK);
 for(int i=0;i<3;i++){
  Profile p;portENTER_CRITICAL(&profileMux);p=profiles[i];portEXIT_CRITICAL(&profileMux);
  int y=48+i*23;
  if(i==profileIndex.load())canvas.fillRoundRect(4,y-3,232,21,4,PANEL2);
  put(8,y,"#"+String(i+1)+"  "+shorten(String(p.ssid),28),i==profileIndex.load()?ACCENT:TEXT,1);
 }
 bottomLabel("1-3 SELECT  |  W EDIT NETWORK");
}
static void renderPlaylist(){put(8,28,"WLED PRESET PLAYLIST",PINK);
 const Catalog* c=activeCatalog.load();int n=c?c->presetCount:0;
 int idx=constrain(app.playlistRow,0,max(0,n-1));
 String label=n?"#"+String(c->presetOrder[idx])+" "+c->preset[c->presetOrder[idx]].name:"No saved presets";
 put(8,44,shorten(label,37),TEXT,1);
 put(8,60,"IN QUEUE: "+String(app.playlistCount)+"  F: ADD",ACCENT);
 put(8,75,"DURATION "+String(app.playlistDuration)+" sec",TEXT);
 put(8,90,"TRANSITION "+String(app.playlistTransition)+" sec",TEXT);
 put(8,105,"ENTER: START SELECTED",GREEN);
 bottomLabel("UP/DOWN: PRESET  +/-: TRANSITION");
}
static void renderLive(){put(8,28,"LIVE LED PREVIEW",PINK);
 if(!wifiOnline.load()){ put(8,56,"Wi-Fi OFF in festival mode",TEXT);
  bottomLabel("K: ONE-TIME WLED SYNC",AMBER);return;}
 if(!liveValid.load()){put(8,53,"WAITING FOR /json/live",TEXT);put(8,68,"Feature may be disabled",FAINT);
 bottomLabel("WLED_ENABLE_JSONLIVE REQUIRED");return;}
 for(int i=0;i<24;i++){
  int x=8+(i%12)*19,y=56+(i/12)*25;
  canvas.fillRoundRect(x,y,15,14,3,livePixels[i]);
 }
 bottomLabel("SAMPLED COLORS (NOT 20-SEG MAP)");
}
static void renderAbout(){put(8,28,"FESTIVAL KIT V6",PINK,2);
 put(8,62,"Cardputer ADV / WLED remote",TEXT);
 put(8,77,"ESP-NOW FIRST / Wi-Fi SYNC",FAINT);
 put(8,92,"Harness protocol ZHR2",TEXT);
 put(8,108,"Updated WLED branch required",FAINT);
 bottomLabel("ZAVEN STUDIOS");
}
static void render(){uint32_t now=millis();if(!dirty||!spriteOK||now-app.lastRender<18)return;
 app.lastRender=now;dirty=false;
 frameBase();
 if(app.locked){put(11,48,"CONTROLS LOCKED",TEXT,2);
  put(11,88,"HOLD L TO UNLOCK",AMBER,1);
  bottomLabel("X STILL BLACKS OUT",ALERT);
 }else switch(app.page){
 case HOME:renderHome();break;case PALETTE_PAGE:renderPalette();break;
 case FX_PAGE:renderBrowser();break;case PRESET_PAGE:renderPresets();break;
 case SETTINGS_PAGE:renderSettings();break;case MENU_PAGE:renderMenu();break;
 case HELP_PAGE:renderHelp();break;case BRIGHT_PAGE:renderBrightness();break;
 case DIAG_PAGE:renderDiag();break;case BATTERY_PAGE:renderBattery();break;
 case WIFI_PAGE:renderWifi();break;case EDITOR_PAGE:renderEditor();break;
 case CONFIRM_PAGE:renderConfirm();break;case ROTATE_PAGE:renderRotation();break;
 case PROFILE_PAGE:renderProfiles();break;case LIVE_PAGE:renderLive();break;
 case PLAYLIST_PAGE:renderPlaylist();break;case ABOUT_PAGE:renderAbout();break;
 default:renderHome();break;
 }
 canvas.pushSprite(0,0);
}
}
namespace FK6 {
static bool writeBackup(){if(!sdReady)return false;
 if(!SD.exists("/ZAVEN_V6"))SD.mkdir("/ZAVEN_V6");
 SD.remove("/ZAVEN_V6/settings.txt");
 File f=SD.open("/ZAVEN_V6/settings.txt",FILE_WRITE);
 if(!f)return false;
 f.println("ZAVEN FESTIVAL KIT V6 SETTINGS");
 f.printf("profile=%d\nbrightness=%d\nauto_rotate=%d\ninterval=%d\n",
  profileIndex.load(),app.screenLight,app.autoRotate,app.rotationSeconds);
 for(int i=0;i<3;i++){
  Profile p;portENTER_CRITICAL(&profileMux);p=profiles[i];portEXIT_CRITICAL(&profileMux);
  f.printf("profile%d_ssid=%s\nprofile%d_host=%s\n",i,p.ssid,i,p.host);
  // Never export Wi-Fi passwords to removable media.
 }
 for(int b=0;b<3;b++){f.printf("bank%d_favorites_hex=",b);
  for(int i=0;i<32;i++)f.printf("%02x",app.favoriteBank[b][i]);
  f.println();}
 f.print("palette_favorites_hex=");for(int i=0;i<32;i++)f.printf("%02x",app.paletteFavorite[i]);f.println();
 f.close();return true;
}
static bool writeCatalogCache(){if(!sdReady)return false;
 const Catalog* c=activeCatalog.load();if(!c)return false;
 if(!SD.exists("/ZAVEN_V6"))SD.mkdir("/ZAVEN_V6");
 SD.remove("/ZAVEN_V6/catalog.bin");
 File f=SD.open("/ZAVEN_V6/catalog.bin",FILE_WRITE);if(!f)return false;
 uint32_t marker=0x5A415636,version=6,ssid=profileHash();
 f.write((const uint8_t*)&marker,4);f.write((const uint8_t*)&version,4);f.write((const uint8_t*)&ssid,4);
 f.write((const uint8_t*)c,sizeof(Catalog));f.close();return true;
}
static bool loadCatalogCache(){if(!sdReady)return false;
 File f=SD.open("/ZAVEN_V6/catalog.bin",FILE_READ);if(!f)return false;
 uint32_t marker=0,version=0,ssid=0;
 if(f.read((uint8_t*)&marker,4)!=4||f.read((uint8_t*)&version,4)!=4||f.read((uint8_t*)&ssid,4)!=4||
    marker!=0x5A415636||version!=6||ssid!=profileHash()||f.size()!=sizeof(Catalog)+12){f.close();return false;}
 if(f.read((uint8_t*)&catalogA,sizeof(Catalog))!=sizeof(Catalog)){f.close();return false;}
 f.close();activeCatalog.store(&catalogA);catReady.store(true);return true;
}
static bool restoreBackup(){
 if(!sdReady)return false;
 File f=SD.open("/ZAVEN_V6/settings.txt",FILE_READ);if(!f)return false;
 int restored=0;
 while(f.available()){
  String line=f.readStringUntil('\n');int equals=line.indexOf('=');if(equals<0)continue;
  String key=line.substring(0,equals),value=line.substring(equals+1);
  while(value.length()&&(value[value.length()-1]=='\n'||value[value.length()-1]=='\r'))value.remove(value.length()-1);
  if(key=="palette_favorites_hex"&&value.length()>=64){
    for(int i=0;i<32;i++){char bytes[3]={value[i*2],value[i*2+1],0};app.paletteFavorite[i]=strtoul(bytes,nullptr,16);}restored++;}
  for(int b=0;b<3;b++)if(key=="bank"+String(b)+"_favorites_hex"&&value.length()>=64){
    for(int i=0;i<32;i++){char bytes[3]={value[i*2],value[i*2+1],0};app.favoriteBank[b][i]=strtoul(bytes,nullptr,16);}
    restored++;}
  for(int i=0;i<3;i++){
    String prefix="profile"+String(i)+"_";
    if(key==prefix+"ssid"){cpy(profiles[i].ssid,sizeof(profiles[i].ssid),value);restored++;}
    if(key==prefix+"host"){cpy(profiles[i].host,sizeof(profiles[i].host),value);restored++;}
  }
 }
 f.close();if(!restored)return false;
 storeBank();prefs.putBytes("palfav",app.paletteFavorite,32);saveProfiles();profileChange.store(1);return true;
}
static void exportSettings(){bool a=writeBackup(),b=writeCatalogCache();
 say((a&&b)?"Settings and catalog saved to SD":(!sdReady?"No microSD inserted":"SD write failed"));
}
static void modifySetting(int direction){int id=settingIndexByRow(app.paramRow);
 if(id<0)return;
 DeviceState st=getDevice();int val=settingValue(st,id);
 if(id>=5)val=!val;else val=constrain(val+direction*(id==4?1:5),0,id==4?31:255);
 if(!v2Capable.load()){say("V2 harness firmware required");return;}
 if(!remoteControl(9,(uint16_t)val,(uint8_t)id)){
    say("ESP-NOW command not sent");return;
 }
 switch(id){case 0:st.sx=val;break;case 1:st.ix=val;break;
 case 2:st.c1=val;break;case 3:st.c2=val;break;case 4:st.c3=val;break;
 case 5:st.options[0]=val;break;case 6:st.options[1]=val;break;case 7:st.options[2]=val;break;}
 putDevice(st);dirty=true;
}
static void doConfirm(){switch(app.confirmType){
 case CONFIRM_SAVE:{
  if(app.confirmedPresetID>0){if(action(ACT_SAVE,app.confirmedPresetID,0,app.editText))say("Saving preset to WLED...");}
  break;}
 case CONFIRM_OVERWRITE:exportSettings();break;
 case CONFIRM_DUP:{
  int id=app.duplicateFrom,newId=nextFreePreset();
  if(id>0&&newId>0)action(ACT_DUP,id,newId,"Copy - "+getPresetLabel(activeCatalog.load(),id));
  break;}
 case CONFIRM_PLAY:{
   String json="{\"playlist\":{\"ps\":[";
   if(app.playlistCount){for(int i=0;i<app.playlistCount;i++){if(i)json+=',';json+=String(app.playlistIds[i]);}}
   else {const Catalog* c=activeCatalog.load();if(c)for(int i=0;i<min(10,(int)c->presetCount);i++){
     if(i)json+=',';
     json+=String(c->presetOrder[i]);}}
   json+= "],\"dur\":"+String(app.playlistDuration*10)+",\"transition\":"+String(app.playlistTransition*10)+",\"repeat\":0}}";
   action(ACT_STATE,0,0,json);break;}
 case CONFIRM_RENAME:action(ACT_RENAME,app.confirmedPresetID,0,app.editText);break;
 case CONFIRM_RESTORE:say(restoreBackup()?"Restored preferences from SD":"Restore unavailable");break;
 default:break;
 }
 app.confirmType=CONFIRM_NONE;goHome();
}
static void pressNavigation(char k){
 if(app.page==PALETTE_PAGE){int n=visiblePaletteCount();
  if(!n)return;
  if(k==';'||k==',')selectPalette((app.paletteRow+n-1)%n);
  else if(k=='.'||k=='/')selectPalette((app.paletteRow+1)%n);
  return;}
 if(app.page==HELP_PAGE){if(k==','||k==';')app.helpIndex=(app.helpIndex+2)%3;
  else if(k=='.'||k=='/')app.helpIndex=(app.helpIndex+1)%3;
  dirty=true;return;}
 if(app.page==FX_PAGE){int n=filteredFxCount();if(!n)return;
  if(k==';'||k==',')app.fxRow=(app.fxRow+n-1)%n;
  else if(k=='.'||k=='/')app.fxRow=(app.fxRow+1)%n;
  dirty=true;return;}
 if(app.page==PRESET_PAGE){const Catalog* c=activeCatalog.load();int n=c?c->presetCount:0;
  if(!n)return;
  if(k==';'||k==',')app.presetRow=(app.presetRow+n-1)%n;
  else if(k=='.'||k=='/')app.presetRow=(app.presetRow+1)%n;
  dirty=true;return;}
 if(app.page==SETTINGS_PAGE){int n=settingCount();if(!n)return;
  if(k==';')app.paramRow=(app.paramRow+n-1)%n;
  else if(k=='.')app.paramRow=(app.paramRow+1)%n;
  else if(k==',')modifySetting(-1);
  else if(k=='/')modifySetting(1);
  dirty=true;return;}
 if(app.page==MENU_PAGE){if(k==';'||k==',')app.menuIndex=(app.menuIndex+menuCount-1)%menuCount;
  else if(k=='.'||k=='/')app.menuIndex=(app.menuIndex+1)%menuCount;
  dirty=true;return;}
 if(app.page==PLAYLIST_PAGE){const Catalog* c=activeCatalog.load();int n=c?c->presetCount:0;
  if(k==';'&&n)app.playlistRow=(app.playlistRow+n-1)%n;
  else if(k=='.'&&n)app.playlistRow=(app.playlistRow+1)%n;
  else if(k==',')app.playlistDuration=constrain((int)app.playlistDuration-5,1,120);
  else if(k=='/')app.playlistDuration=constrain((int)app.playlistDuration+5,1,120);
  dirty=true;return;}
 if(app.page==ROTATE_PAGE){if(k==','||k==';')app.rotateScope=(app.rotateScope+3)%4;
  else if(k=='.'||k=='/')app.rotateScope=(app.rotateScope+1)%4;
  dirty=true;return;}

 if(app.page==HOME){if(k==',')stepFx(-1,false);else if(k=='.')stepFx(1,false);
   else if(k==';'){app.presetRow=0;openPage(PRESET_PAGE);}
   else if(k=='/'){app.paramRow=0;openPage(SETTINGS_PAGE);}
   return;}
}
static void doEnter(){switch(app.page){
 case HOME:app.paramRow=0;openPage(SETTINGS_PAGE);break;
 case BRIGHT_PAGE:goHome();break;
 case PALETTE_PAGE:applyPalette();break;
 case FX_PAGE:{int id=filteredFxAt(app.fxRow);if(id>=0){changeEffect(id);goHome();}break;}
 case PRESET_PAGE:{const Catalog* c=activeCatalog.load();
  if(c&&app.presetRow<c->presetCount){recallPreset(c->presetOrder[app.presetRow]);goHome();}break;}
 case SETTINGS_PAGE:modifySetting(1);break;
 case MENU_PAGE:menuSelect(app.menuIndex);break;
 case HELP_PAGE:app.helpIndex=(app.helpIndex+1)%3;dirty=true;break;
 case EDITOR_PAGE:finishEditor();break;
 case CONFIRM_PAGE:doConfirm();break;
 case ROTATE_PAGE:app.autoRotate=!app.autoRotate;app.lastRotateAt=millis();
  say(app.autoRotate?"Automatic rotation on":"Automatic rotation off");break;
 case PLAYLIST_PAGE:app.confirmType=CONFIRM_PLAY;openPage(CONFIRM_PAGE);break;
 case PROFILE_PAGE:app.page=WIFI_PAGE;dirty=true;break;
 case DIAG_PAGE:if(v2Capable.load())radioSendV2(8);else radioSend(8);
  say("Ping sent");break;
 default:goHome();break;
 }}
static void menuKey(char raw){
 char k=(char)tolower((unsigned char)raw);
 if(k=='1'&&app.page==WIFI_PAGE){beginProfileEdit(EDIT_SSID);return;}
 if(k=='2'&&app.page==WIFI_PAGE){beginProfileEdit(EDIT_PASS);return;}
 if(k=='3'&&app.page==WIFI_PAGE){beginProfileEdit(EDIT_HOST);return;}
 if(k=='4'&&app.page==WIFI_PAGE){profileIndex.store((profileIndex.load()+1)%3);
   saveProfiles();profileChange.store(1);dirty=true;return;}
 if(app.page==BATTERY_PAGE){
  if(k=='['){app.screenLight=constrain((int)app.screenLight-12,12,255);
    M5Cardputer.Display.setBrightness(app.screenLight);prefs.putUChar("light",app.screenLight);
    say("Display brightness "+String(app.screenLight));return;}
  if(k==']'){app.screenLight=constrain((int)app.screenLight+12,12,255);
    M5Cardputer.Display.setBrightness(app.screenLight);prefs.putUChar("light",app.screenLight);
    say("Display brightness "+String(app.screenLight));return;}
  if(k=='a'){app.dimScreen=!app.dimScreen;prefs.putBool("dim",app.dimScreen);
    say(app.dimScreen?"Automatic dimming enabled":"Automatic dimming disabled");return;}
 }
 if(app.page==PROFILE_PAGE&&k>='1'&&k<='3'){
  profileIndex.store(k-'1');saveProfiles();profileChange.store(1);dirty=true;return;}
 if(app.page==PLAYLIST_PAGE&&k=='f'){const Catalog* c=activeCatalog.load();
  if(c&&app.playlistRow<c->presetCount){int id=c->presetOrder[app.playlistRow];
    int found=-1;for(int i=0;i<app.playlistCount;i++)if(app.playlistIds[i]==id)found=i;
    if(found>=0){for(int i=found;i+1<app.playlistCount;i++)app.playlistIds[i]=app.playlistIds[i+1];app.playlistCount--;}
    else if(app.playlistCount<16)app.playlistIds[app.playlistCount++]=id;
    say("Playlist now has "+String(app.playlistCount)+" presets");
  }return;
 }
 if(app.page==ROTATE_PAGE){if(k=='r'){app.randomRotate=!app.randomRotate;dirty=true;return;}
  if(raw=='+'||raw=='='){app.rotationSeconds=constrain((int)app.rotationSeconds+5,5,120);dirty=true;return;}
  if(raw=='-'){app.rotationSeconds=constrain((int)app.rotationSeconds-5,5,120);dirty=true;return;}}
 if(app.page==PLAYLIST_PAGE){if(raw=='+'||raw=='='){app.playlistTransition=constrain((int)app.playlistTransition+1,0,20);dirty=true;return;}
  if(raw=='-'){app.playlistTransition=constrain((int)app.playlistTransition-1,0,20);dirty=true;return;}}
 if(app.page==FX_PAGE&&k=='f'){int id=filteredFxAt(app.fxRow);if(id>=0){toggleFav(id);say("Favorite updated");}return;}
 if(app.page==PALETTE_PAGE){
  const Catalog* c=activeCatalog.load();int pal=(c&&visiblePaletteCount())?paletteAtRow(app.paletteRow):-1;
  if(k=='f'){togglePaletteFavorite(pal);return;}
  if(k=='v'){app.onlyFavPalettes=!app.onlyFavPalettes;app.paletteRow=0;
    if(visiblePaletteCount())selectPalette(0);
    say(app.onlyFavPalettes?"Favorite palettes only":"All palettes");return;}
 }
 if(app.page==PRESET_PAGE&&k=='n'){
  const Catalog* c=activeCatalog.load();if(c&&app.presetRow<c->presetCount){
    app.confirmedPresetID=c->presetOrder[app.presetRow];app.editType=EDIT_RENAME;
    app.editText=c->preset[app.confirmedPresetID].name;openPage(EDITOR_PAGE);
  }return;
 }
 if(app.page==PRESET_PAGE&&k=='d'){const Catalog* c=activeCatalog.load();
  if(c&&app.presetRow<c->presetCount){app.duplicateFrom=c->presetOrder[app.presetRow];
    app.confirmType=CONFIRM_DUP;openPage(CONFIRM_PAGE);}return;}
 if(k>='1'&&k<='9'){useQuick(k-'1');goHome();return;}
 if(k=='0'){useQuick(9);goHome();return;}
 if(k=='p'){togglePower();return;}
 if(k=='x'){blackout();return;}
 if(k=='['||k=='{'){stepFx(-1,true);goHome();return;}
 if(k==']'||k=='}'){stepFx(1,true);goHome();return;}
 if(k=='c'){showPalettePicker();return;}
 if(k=='b'){app.presetRow=0;openPage(PRESET_PAGE);return;}
 if(k=='g'){app.filter=ALL_FX;app.search="";app.fxRow=0;openPage(FX_PAGE);return;}
 if(k=='v'){app.filter=FAVORITE_FX;app.search="";app.fxRow=0;openPage(FX_PAGE);return;}
 if(k=='f'){int id=app.selectedFx>=0?app.selectedFx:getDevice().fx;
  toggleFav(id);say(isFav(id)?"Added favorite":"Removed favorite");return;}
 if(k=='r'){int n=filteredFxCount();if(n>0)changeEffect(filteredFxAt(random(n)));return;}
 if(k=='m'){app.menuIndex=0;openPage(MENU_PAGE);return;}
 if(k=='q'){openSearch();return;}
 if(k=='e'){app.paramRow=0;openPage(SETTINGS_PAGE);return;}
 if(k=='s'){beginSavePreset();return;}
 if(k=='k'){syncRequested.store(true);say("One-time Wi-Fi catalog sync");return;}
 if(k=='z'){undoEffect();return;}
 if(k=='t'){if(v2Capable.load())radioSendV2(8);else radioSend(8);
  say("ESP-NOW ping sent");return;}
 if(k=='i'){openPage(DIAG_PAGE);return;}
 if(k=='d'){openPage(BATTERY_PAGE);return;}
 if(k=='w'){openPage(WIFI_PAGE);return;}
 if(k=='h'){app.helpIndex=0;openPage(HELP_PAGE);return;}
 if(k=='a'){app.autoRotate=!app.autoRotate;app.lastRotateAt=millis();
  say(app.autoRotate?"AUTO rotation ON":"AUTO rotation OFF");return;}
 if(k=='l'){app.locked=true;app.lockHold=millis();dirty=true;return;}
 if(k=='y'){cycleBank();return;}
 if(k=='u'){
  uint32_t now=millis();if(app.tapAt&&now-app.tapAt>=250&&now-app.tapAt<=2000)
   app.bpm=constrain(60000/(int)(now-app.tapAt),50,220);
  app.tapAt=now;say("TAP BPM "+String(app.bpm)+" (local)");return;}
}
static void handleKeyboard(){
 // Hold handling is *not* conditional on isChange() so brightness ramps smoothly.
 const uint32_t now=millis();
 bool plus=M5Cardputer.Keyboard.isKeyPressed('=')||M5Cardputer.Keyboard.isKeyPressed('+');
 bool minus=M5Cardputer.Keyboard.isKeyPressed('-')||M5Cardputer.Keyboard.isKeyPressed('_');
 if(app.locked){
  if(M5Cardputer.Keyboard.isKeyPressed('l')||M5Cardputer.Keyboard.isKeyPressed('L')){
    if(!app.lockHold)app.lockHold=now;
    if(now-app.lockHold>1200){app.locked=false;app.lockHold=0;say("Controls unlocked");}
  }else app.lockHold=0;
  // Emergency blackout remains accessible even while locked.
  if(M5Cardputer.Keyboard.isChange()&&M5Cardputer.Keyboard.isPressed()){
    auto state=M5Cardputer.Keyboard.keysState();for(char k:state.word)if(k=='x'||k=='X')blackout();}
  return;
 }
 // Brightness is accessible from ordinary controls, but not from any text editor,
 // playlist/rotation setup, or Wi-Fi configuration page.
 bool brightAllowed=app.page!=EDITOR_PAGE&&app.page!=WIFI_PAGE&&app.page!=ROTATE_PAGE&&app.page!=PLAYLIST_PAGE&&app.page!=CONFIRM_PAGE;
 int dir=(brightAllowed&&plus!=minus)?(plus?1:-1):0;
 if(dir){
  if(app.holdDirection!=dir){app.holdDirection=dir;app.holdStarted=now;app.lastStep=now;setBrightnessStep(dir);}
  else if(now-app.holdStarted>=310&&now-app.lastStep>=210){app.lastStep=now;setBrightnessStep(dir);}
 }else app.holdDirection=0;
 if(!M5Cardputer.Keyboard.isChange()||!M5Cardputer.Keyboard.isPressed())return;
 auto keys=M5Cardputer.Keyboard.keysState();app.lastInputAt=now;
 bool esc=M5Cardputer.Keyboard.isKeyPressed('`'); // Backtick / top-left key is the Cardputer back key; no KEY_ESCAPE symbol required.
 bool back=keys.del||M5Cardputer.Keyboard.isKeyPressed(KEY_BACKSPACE);
 bool tab=keys.tab||M5Cardputer.Keyboard.isKeyPressed(KEY_TAB);
 if(esc){goHome();return;}
 if(tab){if(app.page==HELP_PAGE){app.helpIndex=(app.helpIndex+1)%3;dirty=true;}
  else{app.helpIndex=0;openPage(HELP_PAGE);}return;}
 if(app.page==EDITOR_PAGE){
  if(keys.enter){finishEditor();return;}
  if(back){if(app.editText.length())app.editText.remove(app.editText.length()-1);dirty=true;return;}
  for(char k:keys.word)if((unsigned char)k>=32&&(unsigned char)k<=126&&app.editText.length()<90){
    app.editText+=k;dirty=true;}
  return;
 }
 if(back){goHome();return;}
 if(keys.enter){doEnter();return;}
 for(char key:keys.word){
  if(key==';'||key==','||key=='.'||key=='/'){
    pressNavigation(key);return;
  }
  if((key=='+'||key=='='||key=='-'||key=='_')&&brightAllowed)continue;
  menuKey(key);return;
 }
 // The physical arrow-position keys were handled above without requiring Fn.
 // Fn arrow codes remain optional for users who choose to press Fn.
 if(keys.fn){
  if(M5Cardputer.Keyboard.isKeyPressed(','))pressNavigation(',');
  else if(M5Cardputer.Keyboard.isKeyPressed('/'))pressNavigation('/');
  else if(M5Cardputer.Keyboard.isKeyPressed(';'))pressNavigation(';');
  else if(M5Cardputer.Keyboard.isKeyPressed('.'))pressNavigation('.');
 }
}
static void synchronizeState(){
 static uint32_t lastSyncSeen=0,lastAckSeen=0;static bool lastWifi=false,lastLink=false;
 DeviceState st=getDevice();bool wifi=wifiOnline.load();bool live=haveRecentAck();
 uint32_t ack=ackTime.load();
 if(ack&&ack!=lastAckSeen){lastAckSeen=ack;
   if(!wifi){st.bri=lastAckBrightness.load();if(lastAckOp.load()==1)st.ps=lastAckPreset.load();
     putDevice(st);}
 }
 if(wifi!=lastWifi||live!=lastLink){lastWifi=wifi;lastLink=live;dirty=true;}
 if(st.lastState&&st.lastState!=lastSyncSeen){
  lastSyncSeen=st.lastState;
  // Respect ~900ms of local optimism before external state overwrites it.
  if(millis()-app.lastInputAt>900){
    if(st.ps>=1&&st.ps!=app.lastSeenPs){app.selectedPreset=st.ps;app.selectedFx=-1;}
    else if(st.fx!=app.lastSeenFx){app.selectedFx=st.fx;app.selectedPreset=-1;}
  }
  app.lastSeenPs=st.ps;app.lastSeenFx=st.fx;
  if(app.page==HOME||app.page==DIAG_PAGE||app.page==SETTINGS_PAGE)dirty=true;
 }
}
static void loadSettings(){
 prefs.begin("zaven-v6",false);
 Preferences legacy;legacy.begin("festival2",true);
 String inheritedPassword=legacy.getString("wledPass","");
 legacy.end();
 for(int b=0;b<3;b++){
  String key="fb"+String(b);
  if(prefs.getBytesLength(key.c_str())==32)prefs.getBytes(key.c_str(),app.favoriteBank[b],32);
 }
 app.bank=constrain(prefs.getUChar("bank",0),0,2);
 if(prefs.getBytesLength("palfav")==32)prefs.getBytes("palfav",app.paletteFavorite,32);
 app.screenLight=constrain(prefs.getUChar("light",78),12,255);
 app.rotationSeconds=constrain(prefs.getUChar("rotation",20),5,120);
 app.dimScreen=prefs.getBool("dim",false);
 for(int i=0;i<3;i++){
  String prefix="p"+String(i);
  String s=prefs.getString((prefix+"ss").c_str(),i==0?"Harness-AP":(i==1?"WLED-AP":""));
  String pass=prefs.getString((prefix+"pw").c_str(),(i==0&&inheritedPassword.length())?inheritedPassword:String("wled1234"));
  String host=prefs.getString((prefix+"ip").c_str(),"");
  cpy(profiles[i].ssid,sizeof(profiles[i].ssid),s);
  cpy(profiles[i].password,sizeof(profiles[i].password),pass);
  cpy(profiles[i].host,sizeof(profiles[i].host),host);
 }
 profileIndex.store(constrain(prefs.getUChar("profile",0),0,2));
 savedRadioChannel.store(constrain(prefs.getUChar("radioch",1),1,11));
}
static void initSD(){
 SPI.begin(40,39,14,12);
 sdReady=SD.begin(12,SPI,8000000);
 if(sdReady)Serial.println("V6 SD available");
 else Serial.println("V6 SD unavailable - online catalog still supported");
}
static void begin(){
 Serial.begin(115200);
 auto cfg=M5.config();M5Cardputer.begin(cfg,true);
 M5Cardputer.Display.setRotation(1);
 loadSettings();M5Cardputer.Display.setBrightness(app.screenLight);
 canvas.setColorDepth(16);spriteOK=canvas.createSprite(240,135)!=nullptr;
 if(!spriteOK){M5Cardputer.Display.fillScreen(BG);M5Cardputer.Display.print("V6 framebuffer error");}
 initSD();loadCatalogCache();
 txSequence=esp_random();app.lastInputAt=millis();app.lastRotateAt=millis();
 WiFi.mode(WIFI_STA);WiFi.setSleep(false);
 xTaskCreatePinnedToCore(networkTask,"WLED_V6_NET",15000,nullptr,1,nullptr,0);
 dirty=true;render();
 Serial.println("ZAVEN STUDIOS FESTIVAL KIT V6  /  Cardputer ADV");
}
static void tick(){
 M5Cardputer.update();handleKeyboard();synchronizeState();
 uint32_t now=millis();
 // Radio worker owns ping schedule; UI must never fight channel scanning.
 if(app.page==BRIGHT_PAGE&&now-app.overlayAt>3000){goHome();}
 if(app.showToast&&now-app.lastToastAt>1450){app.showToast=false;dirty=true;}
 if(app.autoRotate&&now-app.lastRotateAt>app.rotationSeconds*1000UL){
   app.lastRotateAt=now;rotateStep();
 }
 static bool backlightReduced=false;
 if(app.dimScreen&&now-app.lastInputAt>25000){
   if(!backlightReduced){M5Cardputer.Display.setBrightness(max(12,(int)app.screenLight/3));backlightReduced=true;}
 }else if(backlightReduced){M5Cardputer.Display.setBrightness(app.screenLight);backlightReduced=false;}
 if(app.page==BATTERY_PAGE){static uint32_t prior=0;if(now-prior>4000){prior=now;dirty=true;}}
 static uint32_t oldPal=0,oldLive=0;
 if(app.page==PALETTE_PAGE&&paletteVersion.load()!=oldPal){oldPal=paletteVersion.load();dirty=true;}
 if(app.page==LIVE_PAGE&&liveVersion.load()!=oldLive){oldLive=liveVersion.load();dirty=true;}
 // Live LED previews require an explicit Wi-Fi session. Never auto-join the AP.
 // Cache downloaded data to SD only once per catalog rebuild.
 static const Catalog* cached=nullptr;const Catalog* live=activeCatalog.load();
 if(live&&live!=cached&&catReady.load()){
   cached=live;dirty=true;
 }
 render();delay(1);
}
}
