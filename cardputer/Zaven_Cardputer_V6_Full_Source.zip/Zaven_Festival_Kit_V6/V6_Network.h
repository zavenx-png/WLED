#pragma once
#include "V6_Model.h"
namespace FK6 {
static std::atomic<uint32_t> lastAckSequence(0);
static std::atomic<uint8_t> lastAckBrightness(120),lastAckPreset(0),lastAckStatus(0);
static std::atomic<int> lastAckOp(0);
static std::atomic<uint32_t> pendingSequence(0);
static std::atomic<uint32_t> lastRadioTx(0);
static bool radioOK=false; // network task owns init/deinit
static std::atomic<uint32_t> lastPing(0);
static std::atomic<int> palettePageRequest(-1);
static std::atomic<uint8_t> savedRadioChannel(1);
static std::atomic<uint32_t> lastFoundChannel(0);
static uint32_t le32(const uint8_t* b){return uint32_t(b[0])|(uint32_t(b[1])<<8)|(uint32_t(b[2])<<16)|(uint32_t(b[3])<<24);}
// ZHR2 cmd: 16 bytes. ZHA2 response: 24 bytes (see WLED patch README).
// On ESP-NOW ACK do not call Wi-Fi/Preferences/SD: callback must be short.
static void radioReceive(const esp_now_recv_info_t* info,const uint8_t* data,int len){
 if(!data||!info)return;
 const bool v2=len==24&&memcmp(data,"ZHA2",4)==0&&data[4]==2;
 const bool v1=len==13&&memcmp(data,"ZHA1",4)==0&&data[4]==1;
 if(!v2&&!v1)return;
 uint32_t seq=le32(data+(v2?16:9));
 // Accept acknowledgments for the four most recently transmitted commands;
 // radio traffic and UI actions can overlap with periodic ping.
 uint32_t cur=txSequence.load();
 if(uint32_t(cur-seq)>4)return;
 lastAckSequence.store(seq);lastAckStatus.store(data[6]);lastAckOp.store(data[5]);
 ackTime.store(millis());ackPackets.fetch_add(1);radioLinkSeen.store(true);
 espRssi.store(info->rx_ctrl?info->rx_ctrl->rssi:0);
 if(v2){
   v2Capable.store(true);lastAckBrightness.store(data[8]);lastAckPreset.store(data[9]);
   DeviceState state=getDevice();
   state.on=(data[7]&1)!=0;state.bri=data[8];state.ps=data[9];
   state.fx=(int16_t)(uint16_t(data[10])|(uint16_t(data[11])<<8));
   state.pal=data[12];state.sx=data[13];state.ix=data[14];state.mainseg=data[15];
   state.c1=data[20];state.c2=data[21];state.c3=data[22];
   state.options[0]=(data[23]&1)!=0;state.options[1]=(data[23]&2)!=0;
   state.options[2]=(data[23]&4)!=0;
   state.lastState=millis();putDevice(state);
 }else{
   legacyCapable.store(true);lastAckBrightness.store(data[7]);lastAckPreset.store(data[8]);
 }
 lastFoundChannel.store((uint32_t)radioChannel.load());
}
static bool radioStart(){
 if(radioOK)return true;
 if(esp_now_init()!=ESP_OK)return false;
 if(esp_now_register_recv_cb(radioReceive)!=ESP_OK){esp_now_deinit();return false;}
 esp_now_peer_info_t peer={};memcpy(peer.peer_addr,BCAST,6);
 peer.channel=0;peer.ifidx=WIFI_IF_STA;peer.encrypt=false;
 if(esp_now_add_peer(&peer)!=ESP_OK){esp_now_deinit();return false;}
 radioOK=true;espReady.store(true);return true;
}
static void radioStop(){if(radioOK){espReady.store(false);radioOK=false;esp_now_deinit();}}
static bool radioSendV2(uint8_t op,uint16_t value=0,uint8_t arg=0){
 if(!espReady.load())return false;
 uint32_t seq=++txSequence;
 uint8_t buf[16]={'Z','H','R','2',2U,op,(uint8_t)value,(uint8_t)(value>>8),
    255U,arg,0U,0U,(uint8_t)seq,(uint8_t)(seq>>8),(uint8_t)(seq>>16),(uint8_t)(seq>>24)};
 pendingSequence.store(seq);
 esp_err_t rc=esp_now_send(BCAST,buf,sizeof(buf));
 if(rc==ESP_OK){sentPackets.fetch_add(1);lastRadioTx.store(millis());return true;}
 return false;
}
static bool radioSend(uint8_t command,uint8_t data=0){
 if(!espReady.load())return false;
 uint32_t seq=++txSequence;
 uint8_t buf[12]={'Z','H','R','1',1U,command,data,0U,
   (uint8_t)seq,(uint8_t)(seq>>8),(uint8_t)(seq>>16),(uint8_t)(seq>>24)};
 pendingSequence.store(seq);
 esp_err_t rc=esp_now_send(BCAST,buf,sizeof(buf));
 if(rc==ESP_OK){sentPackets.fetch_add(1);lastRadioTx.store(millis());return true;}
 return false;
}
static bool selectChannel(uint8_t ch){
 if(WiFi.status()==WL_CONNECTED||ch<1||ch>11)return false;
 esp_wifi_set_promiscuous(true);
 esp_err_t e=esp_wifi_set_channel(ch,WIFI_SECOND_CHAN_NONE);
 esp_wifi_set_promiscuous(false);
 if(e==ESP_OK){radioChannel.store(ch);return true;}return false;
}
static bool remoteControl(uint8_t v2op,uint16_t value=0,uint8_t arg=0,uint8_t oldOp=0,uint8_t oldVal=0){
 if(!espReady.load())return false;
 if(v2Capable.load())return radioSendV2(v2op,value,arg);
 if(oldOp)return radioSend(oldOp,oldVal);
 // A new harness may not have answered a V2 ping yet. Send anyway.
 return radioSendV2(v2op,value,arg);
}
static String apiBase;
static String getJson(const String& path,int timeout=1700){
 if(WiFi.status()!=WL_CONNECTED)return "";
 HTTPClient http;http.setTimeout(timeout);http.setConnectTimeout(700);
 if(!http.begin(apiBase+path))return "";
 int code=http.GET();lastHttpCode.store(code);String s;
 if(code==200){s=http.getString();}else errorCount.fetch_add(1);
 http.end();return s;
}
static bool postJson(const String& json){
 if(WiFi.status()!=WL_CONNECTED)return false;
 HTTPClient http;http.setTimeout(1600);http.setConnectTimeout(650);
 if(!http.begin(apiBase+"/json/state"))return false;
 http.addHeader("Content-Type","application/json");
 int code=http.POST(json);lastHttpCode.store(code);http.end();
 if(code>=200&&code<300)return true;
 errorCount.fetch_add(1);return false;
}
static bool fetchState(){
 String s=getJson("/json/state",1300);if(!s.length())return false;
 DeviceState snap=getDevice();if(!parseState(s,snap))return false;
 snap.wifiRSSI=WiFi.RSSI();putDevice(snap);lastSync.store(millis());return true;
}
static void catalogBuild(){
 Catalog* old=activeCatalog.load();Catalog* target=old==&catalogA?&catalogB:&catalogA;
 target->~Catalog();
 new (target) Catalog(); // in-place reset; no giant stack temporary
 cpy(target->device,sizeof(target->device),String("WLED HARNESS"));
 for(int i=0;i<10;i++)target->quickSlots[i]=-1;
 workerState.store(2);netBusy.store(true);
 String s=getJson("/json/eff",3500);
 if(!s.length()){netBusy.store(false);workerState.store(4);return;}
 int total=0;parseNames(s,&target->fx[0][0],sizeof(target->fx[0]),MAX_FX,total);
 target->fxCount=total;s="";
 if(!total){netBusy.store(false);workerState.store(4);return;}
 s=getJson("/json/pal",2500);if(s.length())parsePalNames(s,*target);s="";
 s=getJson("/presets.json",4500);if(s.length())parsePresets(s,*target);s="";
 s=getJson("/json/info",1800);if(s.length()){
  J::Span root=J::root(s);cpy(target->device,sizeof(target->device),J::stringMember(s,root,"name","WLED HARNESS"));
  J::Span leds=J::member(s,root,"leds");DeviceState d=getDevice();
  d.ledCount=J::intMember(s,leds,"count",d.ledCount);putDevice(d);
 }s="";
 s=getJson("/json/fxdata",4000);if(s.length())parseFxMeta(s,*target);s="";
 DeviceState d=getDevice();target->mainseg=d.mainseg;
 finishCatalog(*target);
 activeCatalog.store(target);catReady.store(true);workerState.store(3);netBusy.store(false);
 catalogCachePending.store(true);
 Serial.printf("V6 Catalog: %u FX, %u Z, %u palettes, %u presets\n",
 (unsigned)target->fxCount,(unsigned)target->zCount,(unsigned)target->palCount,(unsigned)target->presetCount);
}
static void previewPage(int page){
 String s=getJson("/json/palx?page="+String(page),2200);
 if(!s.length())return;
 Catalog* cat=activeCatalog.load();if(!cat)return;
 // Only the worker writes previews; the display sees completed entries.
 parsePalPreview(s,*cat);rebuildPalOrder(*cat);paletteVersion.fetch_add(1);
}
static void processAction(const Action& a){
 Catalog* c=activeCatalog.load();DeviceState st=getDevice();
 switch(a.type){
  case ACT_FX:{if(!c||a.a<0||a.a>=c->fxCount)break;
   postJson(segmentPatch(st.mainseg,"\"fx\":"+String(a.a)+",\"fxdef\":true"));break;}
  case ACT_PAL:{if(a.a>=0&&a.a<256)postJson(segmentPatch(st.mainseg,"\"pal\":"+String(a.a)));break;}
  case ACT_PRESET:{if(a.a>=1&&a.a<=250)postJson("{\"ps\":"+String(a.a)+"}");break;}
  case ACT_SET:{
    // Allowed segment attributes have been enumerated by settings UI.
    const char* fields[]={"sx","ix","c1","c2","c3","o1","o2","o3","pal"};
    if(a.a>=0&&a.a<9){String val;
      if(a.a>=5&&a.a<=7)val=a.b?"true":"false";
      else val=String((int)a.b);
      postJson(segmentPatch(st.mainseg,"\""+String(fields[a.a])+"\":"+val));
    }break;}
  case ACT_SAVE:{
    if(a.a<1||a.a>250)break;
    // WLED copies current state; sb:false avoids writing segment bounds.
    String name=J::escape(String(a.text));
    postJson("{\"psave\":"+String(a.a)+",\"n\":\""+name+"\",\"ib\":true,\"sb\":false}");
    break;}
  case ACT_DUP:{
    if(a.a<1||a.a>250||a.b<1||a.b>250)break;
    if(postJson("{\"ps\":"+String(a.a)+"}")){
      vTaskDelay(pdMS_TO_TICKS(200));
      postJson("{\"psave\":"+String(a.b)+",\"n\":\""+J::escape(String(a.text))+"\",\"ib\":true,\"sb\":false}");
    }break;}
  case ACT_PLAYLIST:{
    if(!c||c->presetCount==0)break;
    int how=min(10,(int)c->presetCount);String json="{\"playlist\":{\"ps\":[";
    for(int i=0;i<how;i++){if(i)json+=',';json+=String(c->presetOrder[i]);}
    int deci=constrain(a.a,1,1200);
    json+="],\"dur\":"+String(deci)+",\"transition\":"+String(constrain(a.b,0,100))+",\"repeat\":0}}";
    postJson(json);break;}
  case ACT_RENAME:{
   // WLED does not expose a safe name-only preset API. Recall existing state
   // first, then re-save that state with the new name. Do not change bounds.
   if(a.a>=1&&a.a<=250&&postJson("{\"ps\":"+String(a.a)+"}")){
     vTaskDelay(pdMS_TO_TICKS(250));
     postJson("{\"psave\":"+String(a.a)+",\"n\":\""+J::escape(String(a.text))+"\",\"ib\":true,\"sb\":false}");
   }break;}
  case ACT_REFRESH:catalogBuild();break;
  case ACT_STATE:postJson(String(a.text));break;
  case ACT_LIVE:{
     String live=getJson("/json/live",1300);
     if(!live.length()){liveValid.store(false);liveVersion.fetch_add(1);break;}
     J::Span root=J::root(live),list=J::member(live,root,"leds");
     if(!list.ok()||live[list.a]!='['){liveValid.store(false);liveVersion.fetch_add(1);break;}
     uint16_t samples[256]={0};int count=0;
     J::ArrayIterator it(live,list);
     while(it.next()&&count<256){String hex=J::decoded(live,it.v);
       if(hex.length()==6){unsigned long rgb=strtoul(hex.c_str(),nullptr,16);
         samples[count++]=rgb565((rgb>>16)&255,(rgb>>8)&255,rgb&255);
       }
     }
     if(count){for(int i=0;i<24;i++)livePixels[i]=samples[min(count-1,i*count/24)];
       liveValid.store(true);}else liveValid.store(false);
     liveVersion.fetch_add(1);break;}
  default:break;
 }
}
static void setApiHost(const Profile& p){
 IPAddress gw=WiFi.gatewayIP();
 String host=String(p.host);
 if(host.length())apiBase=host.startsWith("http")?host:("http://"+host);
 else if(gw[0]>0&&gw[0]!=255)apiBase="http://"+gw.toString();
 else apiBase="http://4.3.2.1";
}
static void loadProfileToWorker(Profile& p){
 int id=profileIndex.load();id=constrain(id,0,2);
 portENTER_CRITICAL(&profileMux);p=profiles[id];portEXIT_CRITICAL(&profileMux);
}
static bool syncWifiCatalog(const Profile& prof,const Action* extra=nullptr){
 // Called ONLY on first run without a saved catalog or when user requests sync.
 // Never run a background Wi-Fi retry loop in regular festival mode.
 syncInProgress.store(true);workerState.store(1);
 ackTime.store(0);radioLinkSeen.store(false);
 radioStop();WiFi.disconnect(false,false);
 WiFi.mode(WIFI_STA);WiFi.setSleep(false);WiFi.setAutoReconnect(false);
 WiFi.begin(prof.ssid,prof.password);
 uint32_t started=millis();bool connected=false;
 while(millis()-started<12000U){
   if(WiFi.status()==WL_CONNECTED){connected=true;break;}
   vTaskDelay(pdMS_TO_TICKS(60));
 }
 wifiOnline.store(connected);
 if(connected){
   radioChannel.store(WiFi.channel());
   if(WiFi.channel()>=1&&WiFi.channel()<=11){
     savedRadioChannel.store(WiFi.channel());prefs.putUChar("radioch",WiFi.channel());
   }
   setApiHost(prof);
   Serial.printf("V6 One-time catalog sync %s ch=%d host=%s\n",prof.ssid,
         WiFi.channel(),apiBase.c_str());
   fetchState();
   if(extra)processAction(*extra);
   catalogBuild();
   if(catReady.load()){
     // WLED /json/palx: fetch all pages, including custom palettes.
     int maxPage=0;
     for(int page=0;page<=maxPage && page<40;page++){
       String body=getJson("/json/palx?page="+String(page),2300);
       if(!body.length())break;
       J::Span root=J::root(body);
       maxPage=constrain(J::intMember(body,root,"m",0),0,39);
       Catalog* c=activeCatalog.load();if(c){parsePalPreview(body,*c);rebuildPalOrder(*c);}
       vTaskDelay(pdMS_TO_TICKS(5));
     }
     paletteVersion.fetch_add(1);
     // Persist to microSD before disconnecting: survives restarts.
     if(sdReady){
       bool saved=writeCatalogCache();
       syncCompleted.store(saved);
       Serial.println(saved?"V6 CATALOG STORED TO MICROSD":"V6 catalog cache write FAILED");
     }else Serial.println("V6 WARNING: microSD absent; catalog will not survive restart");
   }
 }else{
   Serial.printf("V6 one-time Wi-Fi sync failed, status=%d. Remaining ESP-NOW only.\n",(int)WiFi.status());
 }
 WiFi.disconnect(false,false);wifiOnline.store(false);
 WiFi.mode(WIFI_STA);WiFi.setSleep(false);
 ackTime.store(0);
 workerState.store(connected?3:4);
 syncInProgress.store(false);
 return connected && catReady.load();
}
static void networkTask(void*){
 WiFi.mode(WIFI_STA);WiFi.setSleep(false);WiFi.setAutoReconnect(false);
 WiFi.disconnect(false,false);
 Profile prof;loadProfileToWorker(prof);
 uint8_t ch=savedRadioChannel.load();if(ch<1||ch>11)ch=1;
 selectChannel(ch);radioStart();radioSendV2(8);radioSend(8);
 uint32_t lastProbe=0,lastSweep=millis();
 uint8_t scan=ch;bool firstBootNoCatalog=!catReady.load();
 uint32_t bootAt=millis();
 for(;;){
   if(profileChange.exchange(0)){
     loadProfileToWorker(prof);
     activeCatalog.store(nullptr);catReady.store(false);
     syncCompleted.store(false);lastSync.store(0);
     ackTime.store(0);v2Capable.store(false);legacyCapable.store(false);
     // A new controller means new catalog; don't show stale names.
     firstBootNoCatalog=true;bootAt=millis();
   }
   uint32_t now=millis();
   bool haveAck=ackTime.load()&&now-ackTime.load()<LINK_TIMEOUT;
   // Scan radio channels only while disconnected; stop immediately on ACK.
   if(!haveAck && !syncInProgress.load()){
     if(now-lastSweep>=470U){
       scan=(uint8_t)((scan%11U)+1U);
       selectChannel(scan);
       radioSendV2(8); // V2 ping; keeps channel discovery free of Wi-Fi
       // Legacy harness still answers ZHR1; until V2 is proven use both.
       if(!v2Capable.load())radioSend(8);
       lastSweep=now;
     }
   }else if(haveAck && !syncInProgress.load()){
     if(now-lastProbe>=1400U){
       if(v2Capable.load())radioSendV2(8);else radioSend(8);
       lastProbe=now;
     }
     uint8_t found=radioChannel.load();
     if(found!=savedRadioChannel.load() && found>=1 && found<=11){
       savedRadioChannel.store(found);
       prefs.putUChar("radioch",found);
     }
   }
   // An initial one-time sync ONLY occurs when there is no microSD catalog.
   // Give the radio a chance to establish first; no permanent Wi-Fi attempts.
   bool firstSync=firstBootNoCatalog && now-bootAt>1800U;
   if(firstSync){firstBootNoCatalog=false;syncWifiCatalog(prof);
     radioStop();selectChannel(savedRadioChannel.load());radioStart();
     scan=savedRadioChannel.load();lastSweep=millis();
   }
   if(syncRequested.exchange(false)){
     syncWifiCatalog(prof);
     radioStop();selectChannel(savedRadioChannel.load());radioStart();
     scan=savedRadioChannel.load();lastSweep=millis();
   }
   // Explicit advanced actions temporarily open Wi-Fi, apply one command,
   // refresh cache, and return to ESP-NOW. This never happens on a normal key.
   Action a;
   if(takeAction(a)){
     if(a.type==ACT_REFRESH)syncWifiCatalog(prof);
     else syncWifiCatalog(prof,&a);
     radioStop();selectChannel(savedRadioChannel.load());radioStart();
     scan=savedRadioChannel.load();lastSweep=millis();
   }
   vTaskDelay(pdMS_TO_TICKS(35));
 }
}

}
