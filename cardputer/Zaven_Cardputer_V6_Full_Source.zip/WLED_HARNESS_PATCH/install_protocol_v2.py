#!/usr/bin/env python3
"""Patch the user's custom WLED user_fx.cpp (branch harness-espnow-five-meteors).
No mappings, effects, pin assignments, or other WLED files are changed.
Run from a WLED repository checkout: python3 install_protocol_v2.py
"""
from pathlib import Path
import sys
file=Path('usermods/user_fx/user_fx.cpp')
if not file.exists():
    sys.exit('ERROR: Run from the root of your WLED repository (usermods/user_fx/user_fx.cpp not found).')
s=file.read_text()
if 'ZAVEN ESP-NOW V2 / ZHR2' in s:
    sys.exit('Already patched: no change made.')
start=s.find('// STOPWATCH ESP-NOW REMOTE PROTOCOL V1')
end=s.find('/////////////////\n//  UserMod Class',start)
if start<0 or end<0:sys.exit('ERROR: Could not locate the exact original V1 protocol. Check branch/version; no change made.')
# Replace banner too, leaving formatting line from old V1's preceding divider.
replacement=r'''// ZAVEN ESP-NOW V2 / ZHR2 -- backward compatible with ZHR1
// Paired sender MACs MUST be on the WLED ESP-NOW Remote List.
// 16-byte request: magic ZHR2,version 2,op,value LE16,segment,argument,
//                  reserved[2],sequence LE32. 24-byte ZHA2 response includes
// current effect, palette, brightness, preset, settings and radio state.
// Callback only queues packets. WLED loop applies them and sends ACKs.
// Commands: 1 preset,2 brightness,3 toggle,4 on,5 off,6 effect,
// 7 palette,8 ping,9 setting (argument 0:sx,1:ix,2:c1,3:c2,
// 4:c3,5:o1,6:o2,7:o3). Segment always WLED MAIN segment.
// No segment geometry, bus, pin, group, or map operations exist here.
// Legacy ZHR1/ZHA1 packets remain supported.
// ============================================================================
#if defined(ARDUINO_ARCH_ESP32) && !defined(WLED_DISABLE_ESPNOW)
static portMUX_TYPE zh_radio_mux = portMUX_INITIALIZER_UNLOCKED;
static uint8_t zh_radio_packets[12][16] = {{0}};
static uint8_t zh_radio_lengths[12] = {0};
static uint8_t zh_radio_senders[12][6] = {{0}};
static uint8_t zh_radio_head = 0, zh_radio_tail = 0;
static uint8_t zh_radio_last_sender[6] = {0};
static uint32_t zh_radio_last_seq = 0;
static bool zh_radio_have_last = false;
static inline bool zh_radio_is_paired(const uint8_t* sender) {
  char mac[13];
  snprintf(mac,sizeof(mac),"%02x%02x%02x%02x%02x%02x",
           sender[0],sender[1],sender[2],sender[3],sender[4],sender[5]);
  for (const auto& known: linked_remotes) if(strcmp(known.data(),mac)==0)return true;
  return false;
}
static inline uint32_t zh_radio_u32(const uint8_t* p) {
  return uint32_t(p[0])|(uint32_t(p[1])<<8)|(uint32_t(p[2])<<16)|(uint32_t(p[3])<<24);
}
static void zh_radio_process(void) {
  if(statusESPNow != ESP_NOW_STATE_ON)return;
  // Maximum four per WLED iteration to avoid delaying LED rendering.
  for(uint8_t handled=0;handled<4;handled++){
    uint8_t data[16]={0},sender[6]={0},len=0;
    portENTER_CRITICAL(&zh_radio_mux);
    if(zh_radio_tail!=zh_radio_head){
      uint8_t slot=zh_radio_tail;
      memcpy(data,zh_radio_packets[slot],16);
      memcpy(sender,zh_radio_senders[slot],6);
      len=zh_radio_lengths[slot];
      zh_radio_tail=(zh_radio_tail+1U)%12U;
    }
    portEXIT_CRITICAL(&zh_radio_mux);
    if(!len)return;
    // Pairing is checked again at execution time, not just receipt time.
    if(!zh_radio_is_paired(sender))continue;
    const bool v2=(len==16U && memcmp(data,"ZHR2",4)==0 && data[4]==2U);
    const bool v1=(len==12U && memcmp(data,"ZHR1",4)==0 && data[4]==1U);
    if(!v2&&!v1)continue;
    uint8_t op=data[5], val8=data[6],arg=v2?data[9]:0;
    uint16_t value=v2?(uint16_t(data[6])|(uint16_t(data[7])<<8)):val8;
    uint32_t seq=zh_radio_u32(data+(v2?12:8));
    uint8_t status=0;
    bool duplicate=zh_radio_have_last&&seq==zh_radio_last_seq
       &&memcmp(sender,zh_radio_last_sender,6)==0;
    if(!duplicate){
      bool changed=false;
      Segment& segment=strip.getMainSegment();
      switch(op){
        case 1:
          if(value<1U||value>250U){status=1;break;}
          applyPreset((uint8_t)value,CALL_MODE_BUTTON_PRESET);
          break;
        case 2:
          if(value>255U){status=1;break;}
          bri=(uint8_t)value;changed=true;break;
        case 3:toggleOnOff();changed=true;break;
        case 4:if(!bri){toggleOnOff();changed=true;}break;
        case 5:if(bri){toggleOnOff();changed=true;}break;
        case 6:
          if(!v2){bri=(bri>=239U)?255U:uint8_t(bri+16U);changed=true;break;}
          if(value>=strip.getModeCount()||value>255U){status=1;break;}
          if(currentPlaylist>=0)unloadPlaylist();
          segment.setMode((uint8_t)value,true);changed=true;break;
        case 7:
          if(!v2){bri=(bri<=16U)?1U:uint8_t(bri-16U);changed=true;break;}
          if(value>=getPaletteCount()||value>255U){status=1;break;}
          if(segment.getLightCapabilities()&1)segment.setPalette((uint8_t)value);
          changed=true;break;
        case 8:break;
        case 9:
          if(!v2||value>255U){status=1;break;}
          switch(arg){
            case 0:segment.speed=(uint8_t)value;break;
            case 1:segment.intensity=(uint8_t)value;break;
            case 2:segment.custom1=(uint8_t)value;break;
            case 3:segment.custom2=(uint8_t)value;break;
            case 4:segment.custom3=(uint8_t)(value>31U?31U:value);break;
            case 5:segment.check1=value!=0;break;
            case 6:segment.check2=value!=0;break;
            case 7:segment.check3=value!=0;break;
            default:status=1;break;
          }
          if(!status)changed=true;
          break;
        default:status=1;break;
      }
      if(changed)stateUpdated(CALL_MODE_BUTTON);
      zh_radio_have_last=true;zh_radio_last_seq=seq;
      memcpy(zh_radio_last_sender,sender,6);
    }
    // ACK broadcast via WLED's existing radio peer; do not call esp_now_init.
    if(v1){
      uint8_t ack[13]={'Z','H','A','1',1U,op,status,bri,currentPreset,
        uint8_t(seq),uint8_t(seq>>8),uint8_t(seq>>16),uint8_t(seq>>24)};
      wled::espNow.send(ESPNOW_BROADCAST_ADDRESS,ack,sizeof(ack));
    }else{
      // All scalar state fields are read directly from WLED's main segment.
      Segment& s=strip.getMainSegment();
      uint16_t fx=s.mode;
      uint8_t flags=(bri>0U)?1U:0U;
      uint8_t opts=(s.check1?1U:0U)|(s.check2?2U:0U)|(s.check3?4U:0U);
      uint8_t ack[24]={'Z','H','A','2',2U,op,status,flags,bri,currentPreset,
        uint8_t(fx),uint8_t(fx>>8),s.palette,s.speed,s.intensity,
        strip.getMainSegmentId(),uint8_t(seq),uint8_t(seq>>8),
        uint8_t(seq>>16),uint8_t(seq>>24),s.custom1,s.custom2,s.custom3,opts};
      wled::espNow.send(ESPNOW_BROADCAST_ADDRESS,ack,sizeof(ack));
    }
  }
}
#endif

'''
s=s[:start]+replacement+s[end:]
old='''    if (len != 12U || memcmp(payload,"ZHR1",4) != 0) return false;
    if (payload[4] != 1U || !zh_radio_is_paired(sender)) return true;
    portENTER_CRITICAL(&zh_radio_mux);
    memcpy(zh_radio_sender,sender,6);
    memcpy(zh_radio_packet,payload,12);
    zh_radio_pending=true;
    portEXIT_CRITICAL(&zh_radio_mux);
    return true; // This is our command, don't interpret it as WiZmote or sync.'''
new='''    const bool v1=(len==12U && memcmp(payload,"ZHR1",4)==0 && payload[4]==1U);
    const bool v2=(len==16U && memcmp(payload,"ZHR2",4)==0 && payload[4]==2U);
    if(!v1&&!v2)return false;
    if(!zh_radio_is_paired(sender))return true;
    portENTER_CRITICAL(&zh_radio_mux);
    uint8_t next=(zh_radio_head+1U)%12U;
    if(next!=zh_radio_tail){
      memcpy(zh_radio_packets[zh_radio_head],payload,len);
      memcpy(zh_radio_senders[zh_radio_head],sender,6);
      zh_radio_lengths[zh_radio_head]=len;
      zh_radio_head=next;
    }
    portEXIT_CRITICAL(&zh_radio_mux);
    return true; // Matched custom packet, do not interpret as WiZmote or sync.'''
if s.count(old)!=1:sys.exit('ERROR: callback layout differs: no change made.')
s=s.replace(old,new)
# Keep a backup, don't modify if anchors absent or repeated.
backup=file.with_suffix('.cpp.before_zaven_v2')
if backup.exists():sys.exit('ERROR: existing backup found; move it aside after review to retry.')
backup.write_text(file.read_text())
file.write_text(s)
print('SUCCESS: updated usermods/user_fx/user_fx.cpp, preserving LED effects and mapping.')
print('Backup:',backup)
