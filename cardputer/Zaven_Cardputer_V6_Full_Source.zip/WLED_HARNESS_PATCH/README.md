# WLED harness protocol V2 patch

Patch target: `zavenx-png/WLED`, branch `harness-espnow-five-meteors`, path `usermods/user_fx/user_fx.cpp`.

From the root of a local checkout of the correct WLED repo:

```bash
python3 /path/to/install_protocol_v2.py
git diff -- usermods/user_fx/user_fx.cpp
```

The installer makes a `.before_zaven_v2` backup. It preserves your custom effects and mapping, replaces only the existing `zh_radio_*` receiver block, and replaces only the existing `onEspNowMessage` method body. It does not alter any LED segment geometry or hardware pin settings.

Build with the **same custom WLED build environment previously used for your harness**. This patch is uncompiled against the real WLED toolchain, so review the diff, compile, and keep a working rollback binary before flashing.

## Radio packet specification

ZHR2 command: 16 bytes:

| Offset | Format |
|---|---|
| 0–3 | ASCII `ZHR2` |
| 4 | version `2` |
| 5 | operation |
| 6–7 | unsigned 16-bit value, little endian |
| 8 | segment hint (reserved: actual receiver uses WLED main segment) |
| 9 | parameter index for op 9 |
| 10–11 | reserved |
| 12–15 | unsigned 32-bit sequence, little endian |

Operations: 1 recall preset, 2 set brightness, 3 toggle, 4 on, 5 off, 6 select effect with defaults, 7 select palette, 8 ping, 9 set parameter (0 speed, 1 intensity, 2 custom1, 3 custom2, 4 custom3, 5 option1, 6 option2, 7 option3).

ZHA2 ACK: 24 bytes:

| Offset | Format |
|---|---|
| 0–3 | ASCII `ZHA2` |
| 4 | version `2` |
| 5 | echoed operation |
| 6 | status (`0` accepted, `1` invalid) |
| 7 | flags (bit 0 power on) |
| 8 | actual brightness |
| 9 | actual current preset |
| 10–11 | current main-segment effect ID (LE16) |
| 12 | current palette ID |
| 13 | speed |
| 14 | intensity |
| 15 | main segment ID |
| 16–19 | echoed sequence (LE32) |
| 20–22 | custom1/2/3 |
| 23 | option flags (bits 0/1/2) |

The receiver keeps `ZHR1`/`ZHA1` backwards compatibility. It authorizes WLED linked Remote List MACs before queueing and again before execution. It ignores replayed same-sender sequence numbers and transmits ACKs using WLED's own existing ESP-NOW sender.
