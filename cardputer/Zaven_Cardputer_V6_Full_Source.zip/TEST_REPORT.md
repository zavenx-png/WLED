# Verification report — V6 ESP-NOW First

## Executed local checks

- Native C++17 syntax of Cardputer sketch using package-provided mock interfaces: **PASS**.
- Effect, palette, preset model/parser tests: **PASS**.
- Control/keyboard tests: **PASS**. Assert that `,`/`.` send ZHR2 effect commands, `1–0` send *actual* cached preset IDs including values over 127, palette Enter sends the correct WLED palette ID, power and brightness are sent via ESP-NOW, no HTTP action queue is used for these controls.
- ZHA2 radio ACK parsing: **PASS**. Receiver copies main effect, palette, settings and preset state, plus legacy ZHA1 parsing.
- WLED protocol compilation against simulated custom-WLED structures and packet/ACK simulation: **PASS**. Tests cover effect, palette, custom setting, brightness, preset, ACK, duplicate detection, MAC revalidation, V1 backwards compatibility.
- `WLED_HARNESS_PATCH/install_protocol_v2.py`: Python syntax **PASS**.
- ZIP integrity: inspect with `unzip -t` before distribution.

## Not verified

- **Full Arduino M5Cardputer ADV board-package compilation** (no Arduino core/toolchain in this environment).
- **Full WLED PlatformIO build** of the user's custom `harness-espnow-five-meteors` branch (not accessible for local compilation).
- Actual Cardputer and ESP32 harness radio pairing, battery/runtime, display responsiveness and SD filesystem.
- WLED usermod patch applicability on a locally modified or different user_fx.cpp branch (script checks expected anchors and refuses unexpected source).

## Risks and limitations

- Requires **two new firmware builds** to enable V2 features; not a binary flashing package.
- ESP-NOW broadcasts are paired/authorized by WLED's existing MAC Remote List, but this is not an end-to-end encrypted application protocol; the existing harness uses broadcast ACKs as well.
- Full catalog metadata retention requires Cardputer microSD. A changed WLED effect catalog requires deliberate re-sync.
- One-time catalog download can take longer than basic radio pairing, especially with many WLED palette pages. Wi-Fi is automatically disconnected once finished.
- Admin operations that write WLED preset names/playlists still require deliberate temporary Wi-Fi access. No autonomous periodic Wi-Fi associations during normal festival control.
- WLED changing Wi-Fi channels can necessitate a short ESP-NOW channel scan; stored last channel is tried first.
